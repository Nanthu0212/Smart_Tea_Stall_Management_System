package com.smartteastall.test;

import com.smartteastall.dao.SeatDAO;
import com.smartteastall.model.Seat;

public class SeatTest {

    public static void main(String[] args) {

        Seat seat = new Seat();

        seat.setTableId(1);
        seat.setSeatNumber(1);
        seat.setStatus("AVAILABLE");

        SeatDAO dao = new SeatDAO();

        if (dao.addSeat(seat)) {
            System.out.println("Seat Added Successfully.");
        } else {
            System.out.println("Failed to Add Seat.");
        }

    }
}