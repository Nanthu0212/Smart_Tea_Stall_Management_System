package com.smartteastall.test;

import com.smartteastall.dao.TableDAO;
import com.smartteastall.model.Table;

public class TableTest {

    public static void main(String[] args) {

        Table table = new Table();

        table.setTableName("T1");
        table.setCapacity(4);
        table.setStatus("AVAILABLE");
        table.setLocation("Window");

        TableDAO dao = new TableDAO();

        boolean result = dao.addTable(table);

        if (result) {
            System.out.println("Record Inserted Successfully.");
        } else {
            System.out.println("Failed to Insert Record.");
        }
    }
}