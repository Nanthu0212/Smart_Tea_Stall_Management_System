package com.smartteastall.test;

import java.sql.Connection;

import com.smartteastall.database.DatabaseConnection;

public class ConnectionTest {

    public static void main(String[] args) {

        Connection con = DatabaseConnection.getConnection();

        if (con != null) {

            System.out.println("Connection Test Successful.");

        } else {

            System.out.println("Connection Test Failed.");

        }

    }

}