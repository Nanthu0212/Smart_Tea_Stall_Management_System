package com.smartteastall.model;

public class Damage {

    private int damageId;
    private String itemName;
    private int quantity;
    private double damageCost;
    private String status;

    public Damage() {

    }

    public Damage(int damageId, String itemName, int quantity,
            double damageCost, String status) {

        this.damageId = damageId;
        this.itemName = itemName;
        this.quantity = quantity;
        this.damageCost = damageCost;
        this.status = status;
    }

    public int getDamageId() {
        return damageId;
    }

    public void setDamageId(int damageId) {
        this.damageId = damageId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getDamageCost() {
        return damageCost;
    }

    public void setDamageCost(double damageCost) {
        this.damageCost = damageCost;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Damage [damageId=" + damageId
                + ", itemName=" + itemName
                + ", quantity=" + quantity
                + ", damageCost=" + damageCost
                + ", status=" + status + "]";
    }

}