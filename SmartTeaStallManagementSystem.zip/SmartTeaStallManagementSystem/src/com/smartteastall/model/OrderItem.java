package com.smartteastall.model;

public class OrderItem {

    private int orderItemId;
    private int orderId;
    private int itemId;
    private int quantity;
    private double unitPrice;
    private double subtotal;

    public OrderItem() {

    }

    public OrderItem(int orderItemId, int orderId, int itemId,
            int quantity, double unitPrice, double subtotal) {

        this.orderItemId = orderItemId;
        this.orderId = orderId;
        this.itemId = itemId;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.subtotal = subtotal;
    }

    public int getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(int orderItemId) {
        this.orderItemId = orderItemId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    @Override
    public String toString() {

        return "OrderItem [orderItemId=" + orderItemId
                + ", orderId=" + orderId
                + ", itemId=" + itemId
                + ", quantity=" + quantity
                + ", unitPrice=" + unitPrice
                + ", subtotal=" + subtotal + "]";
    }

}