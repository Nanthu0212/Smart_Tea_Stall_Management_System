package com.smartteastall.model;

import java.sql.Timestamp;

public class Order {

    private int orderId;
    private int tableId;
    private int customerCount;
    private boolean sharingAllowed;
    private String orderStatus;
    private double totalAmount;
    private Timestamp orderTime;

    public Order() {

    }

    public Order(int orderId, int tableId, int customerCount,
            boolean sharingAllowed, String orderStatus,
            double totalAmount, Timestamp orderTime) {

        this.orderId = orderId;
        this.tableId = tableId;
        this.customerCount = customerCount;
        this.sharingAllowed = sharingAllowed;
        this.orderStatus = orderStatus;
        this.totalAmount = totalAmount;
        this.orderTime = orderTime;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getTableId() {
        return tableId;
    }

    public void setTableId(int tableId) {
        this.tableId = tableId;
    }

    public int getCustomerCount() {
        return customerCount;
    }

    public void setCustomerCount(int customerCount) {
        this.customerCount = customerCount;
    }

    public boolean isSharingAllowed() {
        return sharingAllowed;
    }

    public void setSharingAllowed(boolean sharingAllowed) {
        this.sharingAllowed = sharingAllowed;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Timestamp getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(Timestamp orderTime) {
        this.orderTime = orderTime;
    }

    @Override
    public String toString() {
        return "Order [orderId=" + orderId +
                ", tableId=" + tableId +
                ", customerCount=" + customerCount +
                ", sharingAllowed=" + sharingAllowed +
                ", orderStatus=" + orderStatus +
                ", totalAmount=" + totalAmount +
                ", orderTime=" + orderTime + "]";
    }

}