package com.smartteastall.model;

public class Supplier {

    private int supplierId;
    private String supplierName;
    private String phone;
    private String address;
    private String suppliedItem;

    public Supplier() {}

    public Supplier(int supplierId,String supplierName,
            String phone,String address,String suppliedItem){

        this.supplierId=supplierId;
        this.supplierName=supplierName;
        this.phone=phone;
        this.address=address;
        this.suppliedItem=suppliedItem;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSuppliedItem() {
        return suppliedItem;
    }

    public void setSuppliedItem(String suppliedItem) {
        this.suppliedItem = suppliedItem;
    }

}