package com.smartteastall.model;

public class Addon {

    private int addonId;
    private int itemId;
    private String addonName;
    private double addonPrice;

    public Addon() {

    }

    public Addon(int addonId, int itemId, String addonName, double addonPrice) {
        this.addonId = addonId;
        this.itemId = itemId;
        this.addonName = addonName;
        this.addonPrice = addonPrice;
    }

    public int getAddonId() {
        return addonId;
    }

    public void setAddonId(int addonId) {
        this.addonId = addonId;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getAddonName() {
        return addonName;
    }

    public void setAddonName(String addonName) {
        this.addonName = addonName;
    }

    public double getAddonPrice() {
        return addonPrice;
    }

    public void setAddonPrice(double addonPrice) {
        this.addonPrice = addonPrice;
    }

    @Override
    public String toString() {
        return "Addon [addonId=" + addonId +
                ", itemId=" + itemId +
                ", addonName=" + addonName +
                ", addonPrice=" + addonPrice + "]";
    }

}