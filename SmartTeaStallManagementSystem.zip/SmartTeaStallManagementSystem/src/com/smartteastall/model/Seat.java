package com.smartteastall.model;

public class Seat {

    private int seatId;
    private int tableId;
    private int seatNumber;
    private String status;

    // Default Constructor
    public Seat() {
    }

    // Parameterized Constructor
    public Seat(int seatId, int tableId, int seatNumber, String status) {
        this.seatId = seatId;
        this.tableId = tableId;
        this.seatNumber = seatNumber;
        this.status = status;
    }

    public int getSeatId() {
        return seatId;
    }

    public void setSeatId(int seatId) {
        this.seatId = seatId;
    }

    public int getTableId() {
        return tableId;
    }

    public void setTableId(int tableId) {
        this.tableId = tableId;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Seat [seatId=" + seatId +
               ", tableId=" + tableId +
               ", seatNumber=" + seatNumber +
               ", status=" + status + "]";
    }
}