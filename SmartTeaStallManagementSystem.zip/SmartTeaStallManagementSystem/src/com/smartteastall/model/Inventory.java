package com.smartteastall.model;

public class Inventory {

    private int inventoryId;
    private String itemName;
    private double quantity;
    private String unit;
    private double minimumStock;
    private double purchasePrice;

    public Inventory() {}

    public Inventory(int inventoryId, String itemName,
            double quantity, String unit,
            double minimumStock,
            double purchasePrice) {

        this.inventoryId = inventoryId;
        this.itemName = itemName;
        this.quantity = quantity;
        this.unit = unit;
        this.minimumStock = minimumStock;
        this.purchasePrice = purchasePrice;
    }

    public int getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(int inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public double getMinimumStock() {
        return minimumStock;
    }

    public void setMinimumStock(double minimumStock) {
        this.minimumStock = minimumStock;
    }

    public double getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(double purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    @Override
    public String toString() {
        return "Inventory [inventoryId=" + inventoryId +
                ", itemName=" + itemName +
                ", quantity=" + quantity +
                ", unit=" + unit + "]";
    }

}