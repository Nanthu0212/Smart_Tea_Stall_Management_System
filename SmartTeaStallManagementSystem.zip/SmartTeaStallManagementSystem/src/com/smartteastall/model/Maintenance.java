package com.smartteastall.model;

import java.sql.Date;

public class Maintenance {

    private int maintenanceId;
    private String itemName;
    private String problem;
    private double repairCost;
    private Date repairDate;
    private String technician;

    public Maintenance() {

    }

    public Maintenance(int maintenanceId, String itemName,
            String problem, double repairCost,
            Date repairDate, String technician) {

        this.maintenanceId = maintenanceId;
        this.itemName = itemName;
        this.problem = problem;
        this.repairCost = repairCost;
        this.repairDate = repairDate;
        this.technician = technician;
    }

    public int getMaintenanceId() {
        return maintenanceId;
    }

    public void setMaintenanceId(int maintenanceId) {
        this.maintenanceId = maintenanceId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getProblem() {
        return problem;
    }

    public void setProblem(String problem) {
        this.problem = problem;
    }

    public double getRepairCost() {
        return repairCost;
    }

    public void setRepairCost(double repairCost) {
        this.repairCost = repairCost;
    }

    public Date getRepairDate() {
        return repairDate;
    }

    public void setRepairDate(Date repairDate) {
        this.repairDate = repairDate;
    }

    public String getTechnician() {
        return technician;
    }

    public void setTechnician(String technician) {
        this.technician = technician;
    }

    @Override
    public String toString() {
        return "Maintenance [maintenanceId=" + maintenanceId
                + ", itemName=" + itemName
                + ", problem=" + problem
                + ", repairCost=" + repairCost
                + ", repairDate=" + repairDate
                + ", technician=" + technician + "]";
    }

}