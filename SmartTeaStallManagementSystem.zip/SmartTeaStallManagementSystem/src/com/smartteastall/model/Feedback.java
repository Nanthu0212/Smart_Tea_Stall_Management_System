package com.smartteastall.model;

import java.sql.Timestamp;

public class Feedback {

    private int feedbackId;
    private int orderId;
    private int rating;
    private String comments;
    private Timestamp feedbackDate;

    public Feedback() {

    }

    public Feedback(int feedbackId, int orderId, int rating,
            String comments, Timestamp feedbackDate) {

        this.feedbackId = feedbackId;
        this.orderId = orderId;
        this.rating = rating;
        this.comments = comments;
        this.feedbackDate = feedbackDate;
    }

    public int getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(int feedbackId) {
        this.feedbackId = feedbackId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Timestamp getFeedbackDate() {
        return feedbackDate;
    }

    public void setFeedbackDate(Timestamp feedbackDate) {
        this.feedbackDate = feedbackDate;
    }

    @Override
    public String toString() {
        return "Feedback [feedbackId=" + feedbackId +
                ", orderId=" + orderId +
                ", rating=" + rating +
                ", comments=" + comments + "]";
    }

}