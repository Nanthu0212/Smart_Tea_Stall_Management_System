package com.smartteastall.model;

import java.sql.Date;

public class Leave {

    private int leaveId;
    private int employeeId;
    private Date leaveFrom;
    private Date leaveTo;
    private String reason;
    private String status;

    public Leave() {

    }

    public Leave(int leaveId, int employeeId, Date leaveFrom,
            Date leaveTo, String reason, String status) {

        this.leaveId = leaveId;
        this.employeeId = employeeId;
        this.leaveFrom = leaveFrom;
        this.leaveTo = leaveTo;
        this.reason = reason;
        this.status = status;
    }

    public int getLeaveId() {
        return leaveId;
    }

    public void setLeaveId(int leaveId) {
        this.leaveId = leaveId;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public Date getLeaveFrom() {
        return leaveFrom;
    }

    public void setLeaveFrom(Date leaveFrom) {
        this.leaveFrom = leaveFrom;
    }

    public Date getLeaveTo() {
        return leaveTo;
    }

    public void setLeaveTo(Date leaveTo) {
        this.leaveTo = leaveTo;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Leave [leaveId=" + leaveId
                + ", employeeId=" + employeeId
                + ", leaveFrom=" + leaveFrom
                + ", leaveTo=" + leaveTo
                + ", reason=" + reason
                + ", status=" + status + "]";
    }

}