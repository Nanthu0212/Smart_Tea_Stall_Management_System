package com.smartteastall.model;

public class MenuItem {

    private int itemId;
    private int categoryId;
    private String itemName;
    private String description;
    private double price;
    private boolean available;
    private String imagePath;

    public MenuItem() {
    }

    public MenuItem(int itemId, int categoryId, String itemName,
            String description, double price,
            boolean available, String imagePath) {

        this.itemId = itemId;
        this.categoryId = categoryId;
        this.itemName = itemName;
        this.description = description;
        this.price = price;
        this.available = available;
        this.imagePath = imagePath;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    @Override
    public String toString() {

        return "MenuItem [itemId=" + itemId +
                ", categoryId=" + categoryId +
                ", itemName=" + itemName +
                ", price=" + price + "]";
    }

}