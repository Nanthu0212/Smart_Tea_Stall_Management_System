package com.smartteastall.model;

public class Employee {

    private int employeeId;
    private String employeeName;
    private String role;
    private String phone;
    private double salary;
    private double bonus;
    private double deduction;

    public Employee() {

    }

    public Employee(int employeeId, String employeeName,
            String role, String phone,
            double salary,
            double bonus,
            double deduction) {

        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.role = role;
        this.phone = phone;
        this.salary = salary;
        this.bonus = bonus;
        this.deduction = deduction;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public double getDeduction() {
        return deduction;
    }

    public void setDeduction(double deduction) {
        this.deduction = deduction;
    }

    @Override
    public String toString() {
        return "Employee [employeeId=" + employeeId +
                ", employeeName=" + employeeName +
                ", role=" + role +
                ", salary=" + salary + "]";
    }

}