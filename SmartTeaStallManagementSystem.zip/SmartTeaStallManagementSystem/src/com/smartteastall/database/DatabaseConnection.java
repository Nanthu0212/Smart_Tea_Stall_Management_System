package com.smartteastall.database;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/SmartTeaStall";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "Nanthu@2005";

    public static Connection getConnection() {

        try {

            Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);

            System.out.println("Database Connected Successfully.");

            return con;

        } catch (Exception e) {

            System.out.println("Database Connection Failed.");
            e.printStackTrace();

            return null;
        }

    }

}