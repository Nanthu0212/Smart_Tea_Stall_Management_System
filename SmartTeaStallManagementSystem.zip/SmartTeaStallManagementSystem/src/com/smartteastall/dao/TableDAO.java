package com.smartteastall.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Table;

public class TableDAO {


    public boolean addTable(Table table) {

        String query = "INSERT INTO tables(table_name, capacity, status, location) VALUES(?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, table.getTableName());
            ps.setInt(2, table.getCapacity());
            ps.setString(3, table.getStatus());
            ps.setString(4, table.getLocation());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


    public List<Table> getAllTables() {

        List<Table> tableList = new ArrayList<>();

        String query = "SELECT * FROM tables";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(query);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Table table = new Table();

                table.setTableId(rs.getInt("table_id"));
                table.setTableName(rs.getString("table_name"));
                table.setCapacity(rs.getInt("capacity"));
                table.setStatus(rs.getString("status"));
                table.setLocation(rs.getString("location"));

                tableList.add(table);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return tableList;
    }


    public Table getTableById(int tableId) {

        String query = "SELECT * FROM tables WHERE table_id=?";

        Table table = null;

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, tableId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                table = new Table();

                table.setTableId(rs.getInt("table_id"));
                table.setTableName(rs.getString("table_name"));
                table.setCapacity(rs.getInt("capacity"));
                table.setStatus(rs.getString("status"));
                table.setLocation(rs.getString("location"));
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return table;
    }


    public boolean updateTable(Table table) {

        String query = "UPDATE tables SET table_name=?, capacity=?, status=?, location=? WHERE table_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, table.getTableName());
            ps.setInt(2, table.getCapacity());
            ps.setString(3, table.getStatus());
            ps.setString(4, table.getLocation());
            ps.setInt(5, table.getTableId());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


    public boolean deleteTable(int tableId) {

        String query = "DELETE FROM tables WHERE table_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, tableId);

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

}