package com.smartteastall.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Addon;

public class AddonDAO {

    public boolean addAddon(Addon addon) {

        String sql = "INSERT INTO addons(item_id,addon_name,addon_price) VALUES(?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, addon.getItemId());
            ps.setString(2, addon.getAddonName());
            ps.setDouble(3, addon.getAddonPrice());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;

    }

    public List<Addon> getAllAddons() {

        List<Addon> list = new ArrayList<>();

        String sql = "SELECT * FROM addons";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Addon addon = new Addon();

                addon.setAddonId(rs.getInt("addon_id"));
                addon.setItemId(rs.getInt("item_id"));
                addon.setAddonName(rs.getString("addon_name"));
                addon.setAddonPrice(rs.getDouble("addon_price"));

                list.add(addon);

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return list;

    }

}