package com.smartteastall.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Supplier;

public class SupplierDAO {

    public boolean addSupplier(Supplier supplier) {

        String sql = "INSERT INTO suppliers(supplier_name, phone, address, supplied_item) VALUES(?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, supplier.getSupplierName());
            ps.setString(2, supplier.getPhone());
            ps.setString(3, supplier.getAddress());
            ps.setString(4, supplier.getSuppliedItem());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public List<Supplier> getAllSuppliers() {

        List<Supplier> supplierList = new ArrayList<>();

        String sql = "SELECT * FROM suppliers";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Supplier supplier = new Supplier();

                supplier.setSupplierId(rs.getInt("supplier_id"));
                supplier.setSupplierName(rs.getString("supplier_name"));
                supplier.setPhone(rs.getString("phone"));
                supplier.setAddress(rs.getString("address"));
                supplier.setSuppliedItem(rs.getString("supplied_item"));

                supplierList.add(supplier);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return supplierList;
    }

    public Supplier getSupplierById(int supplierId) {

        Supplier supplier = null;

        String sql = "SELECT * FROM suppliers WHERE supplier_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, supplierId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                supplier = new Supplier();

                supplier.setSupplierId(rs.getInt("supplier_id"));
                supplier.setSupplierName(rs.getString("supplier_name"));
                supplier.setPhone(rs.getString("phone"));
                supplier.setAddress(rs.getString("address"));
                supplier.setSuppliedItem(rs.getString("supplied_item"));

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return supplier;
    }

    public boolean updateSupplier(Supplier supplier) {

        String sql = "UPDATE suppliers SET supplier_name=?, phone=?, address=?, supplied_item=? WHERE supplier_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, supplier.getSupplierName());
            ps.setString(2, supplier.getPhone());
            ps.setString(3, supplier.getAddress());
            ps.setString(4, supplier.getSuppliedItem());
            ps.setInt(5, supplier.getSupplierId());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public boolean deleteSupplier(int supplierId) {

        String sql = "DELETE FROM suppliers WHERE supplier_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, supplierId);

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

}