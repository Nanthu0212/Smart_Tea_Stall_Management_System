package com.smartteastall.dao;

import java.sql.*;
import java.util.*;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.MenuItem;

public class MenuItemDAO {

    public boolean addMenuItem(MenuItem item) {

        String sql = "INSERT INTO menu_items(category_id,item_name,description,price,available,image_path) VALUES(?,?,?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, item.getCategoryId());
            ps.setString(2, item.getItemName());
            ps.setString(3, item.getDescription());
            ps.setDouble(4, item.getPrice());
            ps.setBoolean(5, item.isAvailable());
            ps.setString(6, item.getImagePath());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;

    }

    public List<MenuItem> getAllItems() {

        List<MenuItem> list = new ArrayList<>();

        String sql = "SELECT * FROM menu_items ORDER BY category_id ASC, item_name ASC, item_id ASC";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                MenuItem item = new MenuItem();

                item.setItemId(rs.getInt("item_id"));
                item.setCategoryId(rs.getInt("category_id"));
                item.setItemName(rs.getString("item_name"));
                item.setDescription(rs.getString("description"));
                item.setPrice(rs.getDouble("price"));
                item.setAvailable(rs.getBoolean("available"));
                item.setImagePath(rs.getString("image_path"));

                list.add(item);

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return list;

    }

}