package com.smartteastall.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Maintenance;

public class MaintenanceDAO {

    public boolean addMaintenance(Maintenance maintenance) {

        String sql = "INSERT INTO maintenance(item_name, problem, repair_cost, repair_date, technician) VALUES(?,?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, maintenance.getItemName());
            ps.setString(2, maintenance.getProblem());
            ps.setDouble(3, maintenance.getRepairCost());
            ps.setDate(4, maintenance.getRepairDate());
            ps.setString(5, maintenance.getTechnician());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


    public List<Maintenance> getAllMaintenance() {

        List<Maintenance> maintenanceList = new ArrayList<>();

        String sql = "SELECT * FROM maintenance";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Maintenance maintenance = new Maintenance();

                maintenance.setMaintenanceId(rs.getInt("maintenance_id"));
                maintenance.setItemName(rs.getString("item_name"));
                maintenance.setProblem(rs.getString("problem"));
                maintenance.setRepairCost(rs.getDouble("repair_cost"));
                maintenance.setRepairDate(rs.getDate("repair_date"));
                maintenance.setTechnician(rs.getString("technician"));

                maintenanceList.add(maintenance);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return maintenanceList;
    }


    public Maintenance getMaintenanceById(int maintenanceId) {

        Maintenance maintenance = null;

        String sql = "SELECT * FROM maintenance WHERE maintenance_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, maintenanceId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                maintenance = new Maintenance();

                maintenance.setMaintenanceId(rs.getInt("maintenance_id"));
                maintenance.setItemName(rs.getString("item_name"));
                maintenance.setProblem(rs.getString("problem"));
                maintenance.setRepairCost(rs.getDouble("repair_cost"));
                maintenance.setRepairDate(rs.getDate("repair_date"));
                maintenance.setTechnician(rs.getString("technician"));
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return maintenance;
    }


    public boolean updateMaintenance(Maintenance maintenance) {

        String sql = "UPDATE maintenance SET item_name=?, problem=?, repair_cost=?, repair_date=?, technician=? WHERE maintenance_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, maintenance.getItemName());
            ps.setString(2, maintenance.getProblem());
            ps.setDouble(3, maintenance.getRepairCost());
            ps.setDate(4, maintenance.getRepairDate());
            ps.setString(5, maintenance.getTechnician());
            ps.setInt(6, maintenance.getMaintenanceId());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean deleteMaintenance(int maintenanceId) {

        String sql = "DELETE FROM maintenance WHERE maintenance_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, maintenanceId);

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

}