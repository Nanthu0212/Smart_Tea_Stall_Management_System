package com.smartteastall.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Asset;

public class AssetDAO {

    public boolean addAsset(Asset asset) {

        String sql = "INSERT INTO assets(asset_name, category, quantity, price, purchase_date) VALUES(?,?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, asset.getAssetName());
            ps.setString(2, asset.getCategory());
            ps.setInt(3, asset.getQuantity());
            ps.setDouble(4, asset.getPrice());
            ps.setDate(5, asset.getPurchaseDate());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    public List<Asset> getAllAssets() {

        List<Asset> assetList = new ArrayList<>();

        String sql = "SELECT * FROM assets";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Asset asset = new Asset();

                asset.setAssetId(rs.getInt("asset_id"));
                asset.setAssetName(rs.getString("asset_name"));
                asset.setCategory(rs.getString("category"));
                asset.setQuantity(rs.getInt("quantity"));
                asset.setPrice(rs.getDouble("price"));
                asset.setPurchaseDate(rs.getDate("purchase_date"));

                assetList.add(asset);

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return assetList;
    }


    public Asset getAssetById(int assetId) {

        Asset asset = null;

        String sql = "SELECT * FROM assets WHERE asset_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, assetId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                asset = new Asset();

                asset.setAssetId(rs.getInt("asset_id"));
                asset.setAssetName(rs.getString("asset_name"));
                asset.setCategory(rs.getString("category"));
                asset.setQuantity(rs.getInt("quantity"));
                asset.setPrice(rs.getDouble("price"));
                asset.setPurchaseDate(rs.getDate("purchase_date"));

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return asset;
    }

    public boolean updateAsset(Asset asset) {

        String sql = "UPDATE assets SET asset_name=?, category=?, quantity=?, price=?, purchase_date=? WHERE asset_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, asset.getAssetName());
            ps.setString(2, asset.getCategory());
            ps.setInt(3, asset.getQuantity());
            ps.setDouble(4, asset.getPrice());
            ps.setDate(5, asset.getPurchaseDate());
            ps.setInt(6, asset.getAssetId());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public boolean deleteAsset(int assetId) {

        String sql = "DELETE FROM assets WHERE asset_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, assetId);

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

}