package com.smartteastall.dao;

import java.sql.*;
import java.util.*;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Employee;

public class EmployeeDAO {

    public boolean addEmployee(Employee employee) {

        String sql = "INSERT INTO employees(employee_name,role,phone,salary,bonus,deduction) VALUES(?,?,?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, employee.getEmployeeName());
            ps.setString(2, employee.getRole());
            ps.setString(3, employee.getPhone());
            ps.setDouble(4, employee.getSalary());
            ps.setDouble(5, employee.getBonus());
            ps.setDouble(6, employee.getDeduction());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;

    }

    public List<Employee> getAllEmployees() {

        List<Employee> list = new ArrayList<>();

        String sql = "SELECT * FROM employees";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Employee employee = new Employee();

                employee.setEmployeeId(rs.getInt("employee_id"));
                employee.setEmployeeName(rs.getString("employee_name"));
                employee.setRole(rs.getString("role"));
                employee.setPhone(rs.getString("phone"));
                employee.setSalary(rs.getDouble("salary"));
                employee.setBonus(rs.getDouble("bonus"));
                employee.setDeduction(rs.getDouble("deduction"));

                list.add(employee);

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return list;

    }

}