package com.smartteastall.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Seat;

public class SeatDAO {


    public boolean addSeat(Seat seat) {

        String query = "INSERT INTO seats(table_id, seat_number, status) VALUES(?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, seat.getTableId());
            ps.setInt(2, seat.getSeatNumber());
            ps.setString(3, seat.getStatus());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


    public List<Seat> getAllSeats() {

        List<Seat> seatList = new ArrayList<>();

        String query = "SELECT * FROM seats";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(query);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Seat seat = new Seat();

                seat.setSeatId(rs.getInt("seat_id"));
                seat.setTableId(rs.getInt("table_id"));
                seat.setSeatNumber(rs.getInt("seat_number"));
                seat.setStatus(rs.getString("status"));

                seatList.add(seat);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return seatList;
    }


    public Seat getSeatById(int seatId) {

        String query = "SELECT * FROM seats WHERE seat_id=?";

        Seat seat = null;

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, seatId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                seat = new Seat();

                seat.setSeatId(rs.getInt("seat_id"));
                seat.setTableId(rs.getInt("table_id"));
                seat.setSeatNumber(rs.getInt("seat_number"));
                seat.setStatus(rs.getString("status"));
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return seat;
    }


    public boolean updateSeat(Seat seat) {

        String query = "UPDATE seats SET table_id=?, seat_number=?, status=? WHERE seat_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, seat.getTableId());
            ps.setInt(2, seat.getSeatNumber());
            ps.setString(3, seat.getStatus());
            ps.setInt(4, seat.getSeatId());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean deleteSeat(int seatId) {

        String query = "DELETE FROM seats WHERE seat_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, seatId);

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}