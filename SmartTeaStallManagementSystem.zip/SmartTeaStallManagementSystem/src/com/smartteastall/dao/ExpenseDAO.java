package com.smartteastall.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Expense;

public class ExpenseDAO {


    public boolean addExpense(Expense expense) {

        String sql = "INSERT INTO expenses(expense_name, category, amount, expense_date) VALUES(?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, expense.getExpenseName());
            ps.setString(2, expense.getCategory());
            ps.setDouble(3, expense.getAmount());
            ps.setDate(4, expense.getExpenseDate());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public List<Expense> getAllExpenses() {

        List<Expense> expenseList = new ArrayList<>();

        String sql = "SELECT * FROM expenses";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Expense expense = new Expense();

                expense.setExpenseId(rs.getInt("expense_id"));
                expense.setExpenseName(rs.getString("expense_name"));
                expense.setCategory(rs.getString("category"));
                expense.setAmount(rs.getDouble("amount"));
                expense.setExpenseDate(rs.getDate("expense_date"));

                expenseList.add(expense);

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return expenseList;
    }


    public Expense getExpenseById(int expenseId) {

        Expense expense = null;

        String sql = "SELECT * FROM expenses WHERE expense_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, expenseId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                expense = new Expense();

                expense.setExpenseId(rs.getInt("expense_id"));
                expense.setExpenseName(rs.getString("expense_name"));
                expense.setCategory(rs.getString("category"));
                expense.setAmount(rs.getDouble("amount"));
                expense.setExpenseDate(rs.getDate("expense_date"));

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return expense;
    }


    public boolean updateExpense(Expense expense) {

        String sql = "UPDATE expenses SET expense_name=?, category=?, amount=?, expense_date=? WHERE expense_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, expense.getExpenseName());
            ps.setString(2, expense.getCategory());
            ps.setDouble(3, expense.getAmount());
            ps.setDate(4, expense.getExpenseDate());
            ps.setInt(5, expense.getExpenseId());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    public boolean deleteExpense(int expenseId) {

        String sql = "DELETE FROM expenses WHERE expense_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, expenseId);

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

}