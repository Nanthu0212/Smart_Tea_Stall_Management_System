package com.smartteastall.dao;

import java.sql.*;
import java.util.*;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Order;

public class OrderDAO {

    public boolean addOrder(Order order) {

        String sql = "INSERT INTO orders(table_id,customer_count,sharing_allowed,order_status,total_amount) VALUES(?,?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, order.getTableId());
            ps.setInt(2, order.getCustomerCount());
            ps.setBoolean(3, order.isSharingAllowed());
            ps.setString(4, order.getOrderStatus());
            ps.setDouble(5, order.getTotalAmount());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    public List<Order> getAllOrders() {

        List<Order> list = new ArrayList<>();

        String sql = "SELECT * FROM orders";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Order order = new Order();

                order.setOrderId(rs.getInt("order_id"));
                order.setTableId(rs.getInt("table_id"));
                order.setCustomerCount(rs.getInt("customer_count"));
                order.setSharingAllowed(rs.getBoolean("sharing_allowed"));
                order.setOrderStatus(rs.getString("order_status"));
                order.setTotalAmount(rs.getDouble("total_amount"));
                order.setOrderTime(rs.getTimestamp("order_time"));

                list.add(order);

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return list;

    }

}