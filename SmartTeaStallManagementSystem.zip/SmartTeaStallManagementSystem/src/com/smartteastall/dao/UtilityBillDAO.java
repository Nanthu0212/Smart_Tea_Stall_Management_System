package com.smartteastall.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.UtilityBill;

public class UtilityBillDAO {

    public boolean addUtilityBill(UtilityBill bill) {

        String sql = "INSERT INTO utility_bills(bill_type, amount, bill_month, bill_year, payment_status) VALUES(?,?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, bill.getBillType());
            ps.setDouble(2, bill.getAmount());
            ps.setString(3, bill.getBillMonth());
            ps.setInt(4, bill.getBillYear());
            ps.setString(5, bill.getPaymentStatus());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public List<UtilityBill> getAllUtilityBills() {

        List<UtilityBill> billList = new ArrayList<>();

        String sql = "SELECT * FROM utility_bills";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                UtilityBill bill = new UtilityBill();

                bill.setBillId(rs.getInt("bill_id"));
                bill.setBillType(rs.getString("bill_type"));
                bill.setAmount(rs.getDouble("amount"));
                bill.setBillMonth(rs.getString("bill_month"));
                bill.setBillYear(rs.getInt("bill_year"));
                bill.setPaymentStatus(rs.getString("payment_status"));

                billList.add(bill);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return billList;
    }

    public UtilityBill getUtilityBillById(int billId) {

        UtilityBill bill = null;

        String sql = "SELECT * FROM utility_bills WHERE bill_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, billId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                bill = new UtilityBill();

                bill.setBillId(rs.getInt("bill_id"));
                bill.setBillType(rs.getString("bill_type"));
                bill.setAmount(rs.getDouble("amount"));
                bill.setBillMonth(rs.getString("bill_month"));
                bill.setBillYear(rs.getInt("bill_year"));
                bill.setPaymentStatus(rs.getString("payment_status"));
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return bill;
    }


    public boolean updateUtilityBill(UtilityBill bill) {

        String sql = "UPDATE utility_bills SET bill_type=?, amount=?, bill_month=?, bill_year=?, payment_status=? WHERE bill_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, bill.getBillType());
            ps.setDouble(2, bill.getAmount());
            ps.setString(3, bill.getBillMonth());
            ps.setInt(4, bill.getBillYear());
            ps.setString(5, bill.getPaymentStatus());
            ps.setInt(6, bill.getBillId());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public boolean deleteUtilityBill(int billId) {

        String sql = "DELETE FROM utility_bills WHERE bill_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, billId);

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

}