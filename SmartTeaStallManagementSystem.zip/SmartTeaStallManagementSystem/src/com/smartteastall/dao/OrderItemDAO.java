package com.smartteastall.dao;

import java.sql.*;
import java.util.*;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.OrderItem;

public class OrderItemDAO {


    public boolean addOrderItem(OrderItem orderItem) {

        String sql = "INSERT INTO order_items(order_id,item_id,quantity,unit_price,subtotal) VALUES(?,?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, orderItem.getOrderId());
            ps.setInt(2, orderItem.getItemId());
            ps.setInt(3, orderItem.getQuantity());
            ps.setDouble(4, orderItem.getUnitPrice());
            ps.setDouble(5, orderItem.getSubtotal());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public List<OrderItem> getAllOrderItems() {

        List<OrderItem> list = new ArrayList<>();

        String sql = "SELECT * FROM order_items";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                OrderItem item = new OrderItem();

                item.setOrderItemId(rs.getInt("order_item_id"));
                item.setOrderId(rs.getInt("order_id"));
                item.setItemId(rs.getInt("item_id"));
                item.setQuantity(rs.getInt("quantity"));
                item.setUnitPrice(rs.getDouble("unit_price"));
                item.setSubtotal(rs.getDouble("subtotal"));

                list.add(item);

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return list;

    }

}