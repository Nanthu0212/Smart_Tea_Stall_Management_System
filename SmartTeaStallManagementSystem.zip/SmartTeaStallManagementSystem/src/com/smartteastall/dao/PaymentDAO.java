package com.smartteastall.dao;

import java.sql.*;
import java.util.*;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Payment;

public class PaymentDAO {

    public boolean addPayment(Payment payment) {

        String sql = "INSERT INTO payments(order_id,payment_method,payment_status,amount) VALUES(?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, payment.getOrderId());
            ps.setString(2, payment.getPaymentMethod());
            ps.setString(3, payment.getPaymentStatus());
            ps.setDouble(4, payment.getAmount());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    public List<Payment> getAllPayments() {

        List<Payment> list = new ArrayList<>();

        String sql = "SELECT * FROM payments";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Payment payment = new Payment();

                payment.setPaymentId(rs.getInt("payment_id"));
                payment.setOrderId(rs.getInt("order_id"));
                payment.setPaymentMethod(rs.getString("payment_method"));
                payment.setPaymentStatus(rs.getString("payment_status"));
                payment.setAmount(rs.getDouble("amount"));
                payment.setPaymentTime(rs.getTimestamp("payment_time"));

                list.add(payment);

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return list;

    }

}