package com.smartteastall.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Damage;

public class DamageDAO {


    public boolean addDamage(Damage damage) {

        String sql = "INSERT INTO damages(item_name, quantity, damage_cost, status) VALUES(?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, damage.getItemName());
            ps.setInt(2, damage.getQuantity());
            ps.setDouble(3, damage.getDamageCost());
            ps.setString(4, damage.getStatus());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public List<Damage> getAllDamages() {

        List<Damage> damageList = new ArrayList<>();

        String sql = "SELECT * FROM damages";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Damage damage = new Damage();

                damage.setDamageId(rs.getInt("damage_id"));
                damage.setItemName(rs.getString("item_name"));
                damage.setQuantity(rs.getInt("quantity"));
                damage.setDamageCost(rs.getDouble("damage_cost"));
                damage.setStatus(rs.getString("status"));

                damageList.add(damage);

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return damageList;
    }


    public Damage getDamageById(int damageId) {

        Damage damage = null;

        String sql = "SELECT * FROM damages WHERE damage_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, damageId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                damage = new Damage();

                damage.setDamageId(rs.getInt("damage_id"));
                damage.setItemName(rs.getString("item_name"));
                damage.setQuantity(rs.getInt("quantity"));
                damage.setDamageCost(rs.getDouble("damage_cost"));
                damage.setStatus(rs.getString("status"));

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return damage;
    }

    public boolean updateDamage(Damage damage) {

        String sql = "UPDATE damages SET item_name=?, quantity=?, damage_cost=?, status=? WHERE damage_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, damage.getItemName());
            ps.setInt(2, damage.getQuantity());
            ps.setDouble(3, damage.getDamageCost());
            ps.setString(4, damage.getStatus());
            ps.setInt(5, damage.getDamageId());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public boolean deleteDamage(int damageId) {

        String sql = "DELETE FROM damages WHERE damage_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, damageId);

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

}