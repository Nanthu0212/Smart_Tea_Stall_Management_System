package com.smartteastall.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Attendance;

public class AttendanceDAO {

    public boolean addAttendance(Attendance attendance) {

        String sql = "INSERT INTO attendance(employee_id, attendance_date, status) VALUES(?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, attendance.getEmployeeId());
            ps.setDate(2, attendance.getAttendanceDate());
            ps.setString(3, attendance.getStatus());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public List<Attendance> getAllAttendance() {

        List<Attendance> attendanceList = new ArrayList<>();

        String sql = "SELECT * FROM attendance";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Attendance attendance = new Attendance();

                attendance.setAttendanceId(rs.getInt("attendance_id"));
                attendance.setEmployeeId(rs.getInt("employee_id"));
                attendance.setAttendanceDate(rs.getDate("attendance_date"));
                attendance.setStatus(rs.getString("status"));

                attendanceList.add(attendance);

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return attendanceList;
    }

    public Attendance getAttendanceById(int attendanceId) {

        Attendance attendance = null;

        String sql = "SELECT * FROM attendance WHERE attendance_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, attendanceId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                attendance = new Attendance();

                attendance.setAttendanceId(rs.getInt("attendance_id"));
                attendance.setEmployeeId(rs.getInt("employee_id"));
                attendance.setAttendanceDate(rs.getDate("attendance_date"));
                attendance.setStatus(rs.getString("status"));

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return attendance;
    }


    public boolean updateAttendance(Attendance attendance) {

        String sql = "UPDATE attendance SET employee_id=?, attendance_date=?, status=? WHERE attendance_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, attendance.getEmployeeId());
            ps.setDate(2, attendance.getAttendanceDate());
            ps.setString(3, attendance.getStatus());
            ps.setInt(4, attendance.getAttendanceId());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    public boolean deleteAttendance(int attendanceId) {

        String sql = "DELETE FROM attendance WHERE attendance_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, attendanceId);

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

}