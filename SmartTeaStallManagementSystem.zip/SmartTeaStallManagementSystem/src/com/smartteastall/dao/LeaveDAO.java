package com.smartteastall.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Leave;

public class LeaveDAO {


    public boolean addLeave(Leave leave) {

        String sql = "INSERT INTO leaves(employee_id, leave_from, leave_to, reason, status) VALUES(?,?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, leave.getEmployeeId());
            ps.setDate(2, leave.getLeaveFrom());
            ps.setDate(3, leave.getLeaveTo());
            ps.setString(4, leave.getReason());
            ps.setString(5, leave.getStatus());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public List<Leave> getAllLeaves() {

        List<Leave> leaveList = new ArrayList<>();

        String sql = "SELECT * FROM leaves";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Leave leave = new Leave();

                leave.setLeaveId(rs.getInt("leave_id"));
                leave.setEmployeeId(rs.getInt("employee_id"));
                leave.setLeaveFrom(rs.getDate("leave_from"));
                leave.setLeaveTo(rs.getDate("leave_to"));
                leave.setReason(rs.getString("reason"));
                leave.setStatus(rs.getString("status"));

                leaveList.add(leave);

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return leaveList;
    }


    public Leave getLeaveById(int leaveId) {

        Leave leave = null;

        String sql = "SELECT * FROM leaves WHERE leave_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, leaveId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                leave = new Leave();

                leave.setLeaveId(rs.getInt("leave_id"));
                leave.setEmployeeId(rs.getInt("employee_id"));
                leave.setLeaveFrom(rs.getDate("leave_from"));
                leave.setLeaveTo(rs.getDate("leave_to"));
                leave.setReason(rs.getString("reason"));
                leave.setStatus(rs.getString("status"));

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return leave;
    }


    public boolean updateLeave(Leave leave) {

        String sql = "UPDATE leaves SET employee_id=?, leave_from=?, leave_to=?, reason=?, status=? WHERE leave_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, leave.getEmployeeId());
            ps.setDate(2, leave.getLeaveFrom());
            ps.setDate(3, leave.getLeaveTo());
            ps.setString(4, leave.getReason());
            ps.setString(5, leave.getStatus());
            ps.setInt(6, leave.getLeaveId());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    public boolean deleteLeave(int leaveId) {

        String sql = "DELETE FROM leaves WHERE leave_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, leaveId);

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

}