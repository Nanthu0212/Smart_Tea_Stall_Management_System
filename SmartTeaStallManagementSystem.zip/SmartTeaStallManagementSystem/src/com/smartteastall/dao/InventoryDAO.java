package com.smartteastall.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Inventory;

public class InventoryDAO {


    public boolean addInventory(Inventory inventory) {

        String sql = "INSERT INTO inventory(item_name, quantity, unit, minimum_stock, purchase_price) VALUES(?,?,?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, inventory.getItemName());
            ps.setDouble(2, inventory.getQuantity());
            ps.setString(3, inventory.getUnit());
            ps.setDouble(4, inventory.getMinimumStock());
            ps.setDouble(5, inventory.getPurchasePrice());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public List<Inventory> getAllInventory() {

        List<Inventory> inventoryList = new ArrayList<>();

        String sql = "SELECT * FROM inventory";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Inventory inventory = new Inventory();

                inventory.setInventoryId(rs.getInt("inventory_id"));
                inventory.setItemName(rs.getString("item_name"));
                inventory.setQuantity(rs.getDouble("quantity"));
                inventory.setUnit(rs.getString("unit"));
                inventory.setMinimumStock(rs.getDouble("minimum_stock"));
                inventory.setPurchasePrice(rs.getDouble("purchase_price"));

                inventoryList.add(inventory);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return inventoryList;
    }


    public Inventory getInventoryById(int inventoryId) {

        Inventory inventory = null;

        String sql = "SELECT * FROM inventory WHERE inventory_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, inventoryId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                inventory = new Inventory();

                inventory.setInventoryId(rs.getInt("inventory_id"));
                inventory.setItemName(rs.getString("item_name"));
                inventory.setQuantity(rs.getDouble("quantity"));
                inventory.setUnit(rs.getString("unit"));
                inventory.setMinimumStock(rs.getDouble("minimum_stock"));
                inventory.setPurchasePrice(rs.getDouble("purchase_price"));

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return inventory;
    }


    public boolean updateInventory(Inventory inventory) {

        String sql = "UPDATE inventory SET item_name=?, quantity=?, unit=?, minimum_stock=?, purchase_price=? WHERE inventory_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, inventory.getItemName());
            ps.setDouble(2, inventory.getQuantity());
            ps.setString(3, inventory.getUnit());
            ps.setDouble(4, inventory.getMinimumStock());
            ps.setDouble(5, inventory.getPurchasePrice());
            ps.setInt(6, inventory.getInventoryId());

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }


    public boolean deleteInventory(int inventoryId) {

        String sql = "DELETE FROM inventory WHERE inventory_id=?";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, inventoryId);

            int rows = ps.executeUpdate();

            ps.close();
            con.close();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

}