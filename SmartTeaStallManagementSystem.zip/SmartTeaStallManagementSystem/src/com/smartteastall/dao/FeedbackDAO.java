package com.smartteastall.dao;

import java.sql.*;
import java.util.*;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Feedback;

public class FeedbackDAO {

    public boolean addFeedback(Feedback feedback) {

        String sql = "INSERT INTO feedback(order_id,rating,comments) VALUES(?,?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, feedback.getOrderId());
            ps.setInt(2, feedback.getRating());
            ps.setString(3, feedback.getComments());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;

    }

    public List<Feedback> getAllFeedback() {

        List<Feedback> list = new ArrayList<>();

        String sql = "SELECT * FROM feedback";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Feedback feedback = new Feedback();

                feedback.setFeedbackId(rs.getInt("feedback_id"));
                feedback.setOrderId(rs.getInt("order_id"));
                feedback.setRating(rs.getInt("rating"));
                feedback.setComments(rs.getString("comments"));
                feedback.setFeedbackDate(rs.getTimestamp("feedback_date"));

                list.add(feedback);

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return list;

    }

}