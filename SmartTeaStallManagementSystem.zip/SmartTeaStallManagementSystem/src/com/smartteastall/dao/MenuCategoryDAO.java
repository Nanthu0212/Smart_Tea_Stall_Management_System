package com.smartteastall.dao;

import java.sql.*;
import java.util.*;

import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.MenuCategory;

public class MenuCategoryDAO {

    public boolean addCategory(MenuCategory category) {

        String sql = "INSERT INTO menu_categories(category_name,description) VALUES(?,?)";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, category.getCategoryName());
            ps.setString(2, category.getDescription());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public List<MenuCategory> getAllCategories() {

        List<MenuCategory> list = new ArrayList<>();

        String sql = "SELECT * FROM menu_categories ORDER BY category_name ASC, category_id ASC";

        try {

            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                MenuCategory c = new MenuCategory();

                c.setCategoryId(rs.getInt("category_id"));
                c.setCategoryName(rs.getString("category_name"));
                c.setDescription(rs.getString("description"));

                list.add(c);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;

    }

}