package com.smartteastall.main;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.smartteastall.dao.AddonDAO;
import com.smartteastall.dao.AdminDAO;
import com.smartteastall.dao.AssetDAO;
import com.smartteastall.dao.AttendanceDAO;
import com.smartteastall.dao.DamageDAO;
import com.smartteastall.dao.ExpenseDAO;
import com.smartteastall.dao.FeedbackDAO;
import com.smartteastall.dao.LeaveDAO;
import com.smartteastall.dao.MaintenanceDAO;
import com.smartteastall.dao.MenuCategoryDAO;
import com.smartteastall.dao.MenuItemDAO;
import com.smartteastall.dao.SeatDAO;
import com.smartteastall.dao.SupplierDAO;
import com.smartteastall.dao.TableDAO;
import com.smartteastall.dao.UtilityBillDAO;
import com.smartteastall.database.DatabaseConnection;
import com.smartteastall.model.Addon;
import com.smartteastall.model.Admin;
import com.smartteastall.model.Asset;
import com.smartteastall.model.Attendance;
import com.smartteastall.model.Damage;
import com.smartteastall.model.Employee;
import com.smartteastall.model.Expense;
import com.smartteastall.model.Feedback;
import com.smartteastall.model.Inventory;
import com.smartteastall.model.Leave;
import com.smartteastall.model.Maintenance;
import com.smartteastall.model.MenuCategory;
import com.smartteastall.model.MenuItem;
import com.smartteastall.model.Order;
import com.smartteastall.model.OrderItem;
import com.smartteastall.model.Payment;
import com.smartteastall.model.Seat;
import com.smartteastall.model.Supplier;
import com.smartteastall.model.Table;
import com.smartteastall.model.UtilityBill;
import com.smartteastall.service.EmployeeService;
import com.smartteastall.service.InventoryService;
import com.smartteastall.service.OrderService;
import com.smartteastall.service.PaymentService;
import com.smartteastall.service.ReportService;

public class Main {

    private static final java.util.Scanner SC = new java.util.Scanner(System.in);

    
    private static final EmployeeService EMPLOYEE_SERVICE = new EmployeeService();
    private static final InventoryService INVENTORY_SERVICE = new InventoryService();
    private static final OrderService ORDER_SERVICE = new OrderService();
    private static final PaymentService PAYMENT_SERVICE = new PaymentService();
    private static final ReportService REPORT_SERVICE = new ReportService();
    private static final AdminDAO ADMIN_DAO = new AdminDAO();
    private static final AssetDAO ASSET_DAO = new AssetDAO();
    private static final AttendanceDAO ATTENDANCE_DAO = new AttendanceDAO();
    private static final DamageDAO DAMAGE_DAO = new DamageDAO();
    private static final ExpenseDAO EXPENSE_DAO = new ExpenseDAO();
    private static final FeedbackDAO FEEDBACK_DAO = new FeedbackDAO();
    private static final LeaveDAO LEAVE_DAO = new LeaveDAO();
    private static final MaintenanceDAO MAINTENANCE_DAO = new MaintenanceDAO();
    private static final MenuCategoryDAO CATEGORY_DAO = new MenuCategoryDAO();
    private static final MenuItemDAO MENU_DAO = new MenuItemDAO();
    private static final AddonDAO ADDON_DAO = new AddonDAO();
    private static final SupplierDAO SUPPLIER_DAO = new SupplierDAO();
    private static final TableDAO TABLE_DAO = new TableDAO();
    private static final SeatDAO SEAT_DAO = new SeatDAO();
    private static final UtilityBillDAO BILL_DAO = new UtilityBillDAO();

    private static String customerName;
    private static String customerPhone;
    private static int customerCount;
    private static boolean sharingAllowed;
    private static int selectedTableId = -1;
    private static int lastOrderId = -1;

    private static final List<CartLine> CART = new ArrayList<>();

    public static void main(String[] args) {
        printHeader("SMART TEA STALL MANAGEMENT SYSTEM");
        

        if (!testDatabaseConnection()) {
            System.out.println("\nCannot continue because the database connection is unavailable.");
            System.out.println("Check MySQL, database name, JDBC driver and DatabaseConnection.java.");
            return;
        }

        while (true) {
            printHeader("MAIN MENU");
            System.out.println("1. Customer");
            System.out.println("2. Admin");
            System.out.println("3. System Information");
            System.out.println("0. Exit");

            int choice = readInt("Select option: ");

            switch (choice) {
                case 1 -> customerPanel();
                case 2 -> adminLogin();
                case 3 -> systemInformation();
                case 0 -> {
                    System.out.println("\nThank you for using Smart Tea Stall Management System.");
                    SC.close();
                    return;
                }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static boolean testDatabaseConnection() {
        try (java.sql.Connection con = DatabaseConnection.getConnection()) {
            return con != null && !con.isClosed();
        } catch (Exception e) {
            return false;
        }
    }



    private static void customerPanel() {
        while (true) {
            printHeader("CUSTOMER");
            System.out.println("1. Start New Order ");
            System.out.println("2. View Tables");
            System.out.println("3. Browse Menu by Category (Add to Cart)");
            System.out.println("4. View Cart");
            System.out.println("5. Update Cart Quantity");
            System.out.println("6. Remove Cart Item");
            System.out.println("7. Place Order");
            System.out.println("8. Make Payment");
            System.out.println("9. Give Feedback");
            System.out.println("10. View My Order Summary");
            System.out.println("0. Back");

            int choice = readInt("Select option: ");

            switch (choice) {
                case 1 -> startGuidedOrder();
                case 2 -> showTablesForCustomer();
                case 3 -> browseMenuByCategory();
                case 4 -> displayCart();
                case 5 -> updateCartQuantity();
                case 6 -> removeCartItem();
                case 7 -> placeOrder();
                case 8 -> makePayment();
                case 9 -> giveFeedback();
                case 10 -> viewLastOrderSummary();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }


    private static void startGuidedOrder() {
        
        selectedTableId = -1;
        CART.clear();
        lastOrderId = -1;

        
        collectCustomerInformation();

        
        while (selectedTableId <= 0) {
            showTablesForCustomer();
            if (selectedTableId <= 0) {
                if (!readYesNo("No table selected. Try again? (Y/N): ")) {
                    System.out.println("\nOrder cancelled - no table selected.");
                    return;
                }
            }
        }

        
        while (true) {
            browseMenuByCategory();

            if (CART.isEmpty()) {
                System.out.println("\nYour cart is empty.");
                if (!readYesNo("Browse the menu again? (Y/N): ")) {
                    System.out.println("\nOrder cancelled - no items were added.");
                    return;
                }
                continue;
            }

            displayCart();
            if (readYesNo("Proceed to checkout with this cart? (Y/N): ")) {
                break;
            }
            System.out.println("Returning to the menu to add or change items...");
        }

        
        placeOrder();
        if (lastOrderId <= 0) {
            System.out.println("\nOrder could not be placed. Guided flow stopped.");
            return;
        }

        
        makePayment();

        
        if (readYesNo("Would you like to give feedback? (Y/N): ")) {
            giveFeedback();
        }

        System.out.println("\nThank you! Your order is complete.");
    }

    private static void collectCustomerInformation() {
        printHeader("CUSTOMER INFORMATION");
        customerName = readRequiredString("Customer name: ");
        customerPhone = readRequiredString("Mobile number: ");
        customerCount = readIntRange("Number of people: ", 1, 100);
        sharingAllowed = readYesNo("Allow table sharing? (Y/N): ");

        System.out.println("\nCustomer session updated.");
        System.out.println("Name    : " + customerName);
        System.out.println("Phone   : " + customerPhone);
        System.out.println("People  : " + customerCount);
        System.out.println("Sharing : " + (sharingAllowed ? "YES" : "NO"));
    }

    private static void showTablesForCustomer() {
        printHeader("TABLE SELECTION");

        List<Table> tables = TABLE_DAO.getAllTables();
        if (tables.isEmpty()) {
            System.out.println("No tables found in the database.");
            return;
        }

        System.out.println("ID" + "\t" + "TABLE" + "\t" + "CAPACITY" + "\t" + "STATUS" + "\t" + "LOCATION");
        line(75);

        for (Table t : tables) {
            System.out.println(t.getTableId() + "\t" + safe(t.getTableName()) + "\t" + t.getCapacity()
                    + "\t" + safe(t.getStatus()) + "\t" + safe(t.getLocation()));
        }

        if (customerCount <= 0) {
            System.out.println("\nEnter customer information first if you want a recommendation.");
        }

        if (customerCount > 0) {
            System.out.println("\nRecommended available tables for " + customerCount + " people:");
            boolean found = false;
            for (Table t : tables) {
                if (t.getCapacity() >= customerCount && isAvailable(t.getStatus())) {
                    System.out.println("  -> " + t.getTableId() + " | " + t.getTableName()
                            + " | capacity " + t.getCapacity());
                    found = true;
                }
            }
            if (!found) {
                System.out.println("  No suitable available table found.");
            }
        }

        int id = readInt("Enter table ID to select, or 0 to cancel: ");
        if (id == 0) return;

        Table selected = TABLE_DAO.getTableById(id);
        if (selected == null) {
            System.out.println("Table not found.");
            return;
        }
        if (!isAvailable(selected.getStatus())) {
            System.out.println("Selected table is not available.");
            return;
        }
        if (customerCount > 0 && selected.getCapacity() < customerCount) {
            System.out.println("Table capacity is smaller than the customer count.");
            return;
        }

        selectedTableId = id;
        System.out.println("Table selected: " + selected.getTableName());
    }



    private static void displayMenu(boolean onlyAvailable) {
        printHeader("MENU");

        List<MenuCategory> categories = CATEGORY_DAO.getAllCategories();
        List<MenuItem> items = MENU_DAO.getAllItems();

        if (categories.isEmpty()) {
            System.out.println("No menu categories found.");
            return;
        }

        Map<Integer, String> categoryNames = new HashMap<>();
        for (MenuCategory category : categories) {
            categoryNames.put(category.getCategoryId(), category.getCategoryName());
        }

        boolean displayedAny = false;

        for (MenuCategory category : categories) {
            boolean categoryPrinted = false;

            for (MenuItem item : items) {
                if (item.getCategoryId() != category.getCategoryId()) continue;
                if (onlyAvailable && !item.isAvailable()) continue;

                if (!categoryPrinted) {
                    System.out.println("\n" + safe(category.getCategoryName()).toUpperCase());
                    line(80);
                    System.out.println("ID" + "\t" + "ITEM" + "\t" + "PRICE" + "\t" + "STATUS");
                    line(80);
                    categoryPrinted = true;
                }

                System.out.println(item.getItemId() + "\t" + safe(item.getItemName()) + "\t₹" + item.getPrice()
                        + "\t" + (item.isAvailable() ? "Available" : "Unavailable"));
                displayedAny = true;
            }
        }

        for (MenuItem item : items) {
            if (!categoryNames.containsKey(item.getCategoryId())) {
                if (onlyAvailable && !item.isAvailable()) continue;
                if (!displayedAny) {
                    System.out.println("\nOTHER");
                    line(80);
                }
                System.out.println(item.getItemId() + "\t" + safe(item.getItemName()) + "\t₹" + item.getPrice()
                        + "\t" + (item.isAvailable() ? "Available" : "Unavailable"));
                displayedAny = true;
            }
        }

        if (!displayedAny) {
            System.out.println("No menu items found.");
        }
    }

    private static void browseMenuByCategory() {
        while (true) {
            List<MenuCategory> categories = getCategoriesWithAvailableItems();

            printHeader("MENU CATEGORIES");
            if (categories.isEmpty()) {
                System.out.println("No menu categories with available items were found.");
                return;
            }

            System.out.println("ID" + "\t" + "CATEGORY");
            line(40);
            for (MenuCategory category : categories) {
                System.out.println(category.getCategoryId() + "\t" + safe(category.getCategoryName()));
            }

            if (!CART.isEmpty()) {
                System.out.println("\nCart so far: " + CART.size() + " item type(s), total ₹" + cartTotal());
            }

            int categoryId = readInt("Select a category ID to view items, or 0 to finish browsing: ");
            if (categoryId == 0) return;

            MenuCategory selectedCategory = null;
            for (MenuCategory category : categories) {
                if (category.getCategoryId() == categoryId) {
                    selectedCategory = category;
                    break;
                }
            }

            if (selectedCategory == null) {
                System.out.println("Invalid category ID.");
                continue;
            }

            browseItemsInCategory(selectedCategory);
            
        }
    }

    private static List<MenuCategory> getCategoriesWithAvailableItems() {
        List<MenuCategory> categories = CATEGORY_DAO.getAllCategories();
        List<MenuItem> items = MENU_DAO.getAllItems();

        List<MenuCategory> result = new ArrayList<>();
        for (MenuCategory category : categories) {
            for (MenuItem item : items) {
                if (item.getCategoryId() == category.getCategoryId() && item.isAvailable()) {
                    result.add(category);
                    break;
                }
            }
        }
        return result;
    }

    private static List<MenuItem> getAvailableItemsInCategory(int categoryId) {
        List<MenuItem> result = new ArrayList<>();
        for (MenuItem item : MENU_DAO.getAllItems()) {
            if (item.getCategoryId() == categoryId && item.isAvailable()) {
                result.add(item);
            }
        }
        return result;
    }

    private static void browseItemsInCategory(MenuCategory category) {
        while (true) {
            List<MenuItem> items = getAvailableItemsInCategory(category.getCategoryId());

            printHeader(safe(category.getCategoryName()).toUpperCase());
            if (items.isEmpty()) {
                System.out.println("No available items in this category right now.");
                return;
            }

            System.out.println("ID" + "\t" + "ITEM" + "\t" + "PRICE");
            line(55);
            for (MenuItem item : items) {
                System.out.println(item.getItemId() + "\t" + safe(item.getItemName()) + "\t₹" + item.getPrice());
            }

            System.out.println("\n0. Back to Category List");
            int itemId = readInt("Enter item ID to add to cart, or 0 to go back: ");
            if (itemId == 0) return;

            MenuItem selectedItem = null;
            for (MenuItem item : items) {
                if (item.getItemId() == itemId) {
                    selectedItem = item;
                    break;
                }
            }

            if (selectedItem == null) {
                System.out.println("Invalid item ID for this category.");
                continue;
            }

            int quantity = readIntRange("Quantity: ", 1, 1000);
            addToCart(selectedItem, quantity);

            
            if (!readYesNo("Add another item from " + safe(category.getCategoryName()) + "? (Y/N): ")) {
                return;
            }
        }
    }

    private static void addToCart(MenuItem item, int quantity) {
        for (CartLine line : CART) {
            if (line.item.getItemId() == item.getItemId()) {
                line.quantity += quantity;
                System.out.println("Cart quantity updated: " + item.getItemName()
                        + " (now " + line.quantity + ")");
                return;
            }
        }

        CART.add(new CartLine(item, quantity));
        System.out.println("Added to cart: " + item.getItemName() + " x " + quantity);
    }

    private static void displayCart() {
        printHeader("CART");

        if (CART.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }

        double total = 0;
        System.out.println("#" + "\t" + "ITEM" + "\t" + "QTY" + "\t" + "UNIT PRICE" + "\t" + "SUBTOTAL");
        line(75);

        int index = 1;
        for (CartLine line : CART) {
            double subtotal = line.item.getPrice() * line.quantity;
            total += subtotal;
            System.out.println((index++) + "\t" + safe(line.item.getItemName()) + "\t" + line.quantity
                    + "\t₹" + line.item.getPrice() + "\t₹" + subtotal);
        }

        line(75);
        System.out.println("TOTAL: ₹" + total);
    }

    private static void updateCartQuantity() {
        displayCart();
        if (CART.isEmpty()) return;

        int index = readInt("Cart item number (0 to cancel): ");
        if (index == 0) return;
        if (index < 1 || index > CART.size()) {
            System.out.println("Invalid cart item.");
            return;
        }

        int quantity = readIntRange("New quantity: ", 1, 1000);
        CART.get(index - 1).quantity = quantity;
        System.out.println("Cart updated.");
    }

    private static void removeCartItem() {
        displayCart();
        if (CART.isEmpty()) return;

        int index = readInt("Cart item number (0 to cancel): ");
        if (index == 0) return;
        if (index < 1 || index > CART.size()) {
            System.out.println("Invalid cart item.");
            return;
        }

        CartLine removed = CART.remove(index - 1);
        System.out.println("Removed: " + removed.item.getItemName());
    }


    private static void placeOrder() {
        if (CART.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }
        if (selectedTableId <= 0) {
            System.out.println("Select a table before placing the order.");
            return;
        }
        if (customerCount <= 0) {
            System.out.println("Enter customer information before placing the order.");
            return;
        }

        displayCart();
        if (!readYesNo("Place this order? (Y/N): ")) return;

        double total = cartTotal();

        Order order = new Order();
        order.setTableId(selectedTableId);
        order.setCustomerCount(customerCount);
        order.setSharingAllowed(sharingAllowed);
        order.setOrderStatus("PLACED");
        order.setTotalAmount(total);
        order.setOrderTime(new Timestamp(System.currentTimeMillis()));

        if (!ORDER_SERVICE.createOrder(order)) {
            System.out.println("Order creation failed.");
            return;
        }

        lastOrderId = getLatestOrderId();
        if (lastOrderId <= 0) {
            System.out.println("Order was created, but its ID could not be resolved.");
            System.out.println("No order items/payment were inserted.");
            return;
        }

        boolean allItemsSaved = true;
        for (CartLine line : CART) {
            OrderItem orderItem = new OrderItem();
            orderItem.setOrderId(lastOrderId);
            orderItem.setItemId(line.item.getItemId());
            orderItem.setQuantity(line.quantity);
            orderItem.setUnitPrice(line.item.getPrice());
            orderItem.setSubtotal(line.item.getPrice() * line.quantity);

            if (!ORDER_SERVICE.addOrderItem(orderItem)) {
                allItemsSaved = false;
                System.out.println("Failed to save order item: " + line.item.getItemName());
            }
        }

        Table table = TABLE_DAO.getTableById(selectedTableId);
        if (table != null) {
            table.setStatus("FULL");
            TABLE_DAO.updateTable(table);
        }

        if (allItemsSaved) {
            System.out.println("\nOrder placed successfully.");
        } else {
            System.out.println("\nOrder created, but one or more order items failed.");
        }

        System.out.println("Order ID : " + lastOrderId);
        System.out.println("Customer : " + safe(customerName));
        System.out.println("Table    : " + selectedTableId);
        System.out.println("Total    : ₹" + total);
        System.out.println("Payment can now be made from Customer -> Make Payment.");

        CART.clear();
    }

    private static int getLatestOrderId() {
        List<Order> orders = ORDER_SERVICE.getAllOrders();
        int maxId = -1;
        for (Order order : orders) {
            if (order.getOrderId() > maxId) maxId = order.getOrderId();
        }
        return maxId;
    }

    private static void makePayment() {
        if (lastOrderId <= 0) {
            System.out.println("No current order selected. Place an order first.");
            return;
        }

        Order order = null;
        for (Order o : ORDER_SERVICE.getAllOrders()) {
            if (o.getOrderId() == lastOrderId) {
                order = o;
                break;
            }
        }

        if (order == null) {
            System.out.println("Order not found.");
            return;
        }

        printHeader("PAYMENT");
        System.out.println("Order ID : " + order.getOrderId());
        System.out.println("Amount   : ₹" + order.getTotalAmount());
        System.out.println("1. CASH");
        System.out.println("2. UPI");
        System.out.println("3. CARD");

        int method = readIntRange("Payment method: ", 1, 3);
        String paymentMethod = switch (method) {
            case 1 -> "CASH";
            case 2 -> "UPI";
            default -> "CARD";
        };

        Payment payment = new Payment();
        payment.setOrderId(order.getOrderId());
        payment.setPaymentMethod(paymentMethod);
        payment.setPaymentStatus("PAID");
        payment.setAmount(order.getTotalAmount());
        payment.setPaymentTime(new Timestamp(System.currentTimeMillis()));

        if (PAYMENT_SERVICE.makePayment(payment)) {
            System.out.println("Payment recorded successfully.");
            System.out.println("Method: " + paymentMethod);
            System.out.println("Amount: ₹" + payment.getAmount());
        } else {
            System.out.println("Payment could not be recorded.");
        }
    }

    private static void viewLastOrderSummary() {
        if (lastOrderId <= 0) {
            System.out.println("No order selected in this session.");
            return;
        }

        for (Order order : ORDER_SERVICE.getAllOrders()) {
            if (order.getOrderId() == lastOrderId) {
                printHeader("ORDER SUMMARY");
                System.out.println("Order ID       : " + order.getOrderId());
                System.out.println("Table ID       : " + order.getTableId());
                System.out.println("Customer Count : " + order.getCustomerCount());
                System.out.println("Sharing        : " + (order.isSharingAllowed() ? "YES" : "NO"));
                System.out.println("Status         : " + order.getOrderStatus());
                System.out.println("Total          : ₹" + order.getTotalAmount());
                System.out.println("Order Time     : " + order.getOrderTime());
                return;
            }
        }

        System.out.println("Order not found.");
    }

    private static void giveFeedback() {
        if (lastOrderId <= 0) {
            System.out.println("Place an order before giving feedback.");
            return;
        }

        printHeader("FEEDBACK");
        int rating = readIntRange("Rating (1-5): ", 1, 5);
        String comments = readLine("Comments: ");

        Feedback feedback = new Feedback();
        feedback.setOrderId(lastOrderId);
        feedback.setRating(rating);
        feedback.setComments(comments);
        feedback.setFeedbackDate(new Timestamp(System.currentTimeMillis()));

        if (FEEDBACK_DAO.addFeedback(feedback)) {
            System.out.println("Thank you. Feedback saved.");
        } else {
            System.out.println("Feedback could not be saved.");
        }
    }


    private static void adminLogin() {
        printHeader("ADMIN LOGIN");
        String username = readRequiredString("Username: ");
        String password = readRequiredString("Password: ");

        if (ADMIN_DAO.login(username, password)) {
            System.out.println("Login successful.");
            adminDashboard();
        } else {
            System.out.println("Invalid username or password.");
        }
    }

    private static void adminDashboard() {
        while (true) {
            printHeader("ADMIN DASHBOARD");
            System.out.println("1. Dashboard Summary");
            System.out.println("2. Menu Management");
            System.out.println("3. Add-ons");
            System.out.println("4. Orders");
            System.out.println("5. Payments");
            System.out.println("6. Tables");
            System.out.println("7. Seats");
            System.out.println("8. Employees");
            System.out.println("9. Inventory");
            System.out.println("10. Suppliers");
            System.out.println("11. Assets");
            System.out.println("12. Expenses");
            System.out.println("13. Utility Bills");
            System.out.println("14. Maintenance");
            System.out.println("15. Damage");
            System.out.println("16. Attendance");
            System.out.println("17. Leave Management");
            System.out.println("18. Feedback");
            System.out.println("19. Reports");
            System.out.println("20. Admin Account");
            System.out.println("0. Logout");

            int choice = readInt("Select option: ");

            switch (choice) {
                case 1 -> REPORT_SERVICE.printDashboardSummary();
                case 2 -> menuManagement();
                case 3 -> addonManagement();
                case 4 -> displayOrders();
                case 5 -> displayPayments();
                case 6 -> tableManagement();
                case 7 -> seatManagement();
                case 8 -> employeeManagement();
                case 9 -> inventoryManagement();
                case 10 -> supplierManagement();
                case 11 -> assetManagement();
                case 12 -> expenseManagement();
                case 13 -> utilityBillManagement();
                case 14 -> maintenanceManagement();
                case 15 -> damageManagement();
                case 16 -> attendanceManagement();
                case 17 -> leaveManagement();
                case 18 -> displayFeedback();
                case 19 -> reportMenu();
                case 20 -> adminAccountManagement();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }


    private static void menuManagement() {
        while (true) {
            printHeader("MENU MANAGEMENT");
            System.out.println("1. View Categories");
            System.out.println("2. Add Category");
            System.out.println("3. View All Menu Items");
            System.out.println("4. Add Menu Item");
            System.out.println("0. Back");

            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displayCategories();
                case 2 -> addCategory();
                case 3 -> displayMenu(false);
                case 4 -> addMenuItem();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displayCategories() {
        printHeader("MENU CATEGORIES");
        List<MenuCategory> list = CATEGORY_DAO.getAllCategories();
        if (list.isEmpty()) {
            System.out.println("No categories found.");
            return;
        }
        System.out.println("ID" + "\t" + "CATEGORY" + "\t" + "DESCRIPTION");
        line(80);
        for (MenuCategory c : list) {
            System.out.println(c.getCategoryId() + "\t" + safe(c.getCategoryName()) + "\t" + safe(c.getDescription()));
        }
    }

    private static void addCategory() {
        printHeader("ADD MENU CATEGORY");
        MenuCategory category = new MenuCategory();
        category.setCategoryName(readRequiredString("Category name: "));
        category.setDescription(readLine("Description: "));

        System.out.println(CATEGORY_DAO.addCategory(category)
                ? "Category added successfully."
                : "Failed to add category.");
    }

    private static void addMenuItem() {
        printHeader("ADD MENU ITEM");
        displayCategories();

        MenuItem item = new MenuItem();
        item.setCategoryId(readInt("Category ID: "));
        item.setItemName(readRequiredString("Item name: "));
        item.setDescription(readLine("Description: "));
        item.setPrice(readDouble("Price: "));
        item.setAvailable(readYesNo("Available? (Y/N): "));
        item.setImagePath(readLine("Image path (optional): "));

        System.out.println(MENU_DAO.addMenuItem(item)
                ? "Menu item added successfully."
                : "Failed to add menu item.");
    }

    private static void addonManagement() {
        while (true) {
            printHeader("ADD-ONS");
            System.out.println("1. View Add-ons");
            System.out.println("2. Add Add-on");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displayAddons();
                case 2 -> addAddon();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displayAddons() {
        printHeader("ADD-ONS");
        List<Addon> list = ADDON_DAO.getAllAddons();
        if (list.isEmpty()) {
            System.out.println("No add-ons found.");
            return;
        }
        System.out.println("ID" + "\t" + "ITEM ID" + "\t" + "ADD-ON" + "\t" + "PRICE");
        line(65);
        for (Addon a : list) {
            System.out.println(a.getAddonId() + "\t" + a.getItemId() + "\t" + safe(a.getAddonName()) + "\t₹" + a.getAddonPrice());
        }
    }

    private static void addAddon() {
        Addon addon = new Addon();
        addon.setItemId(readInt("Menu item ID: "));
        addon.setAddonName(readRequiredString("Add-on name: "));
        addon.setAddonPrice(readDouble("Add-on price: "));
        System.out.println(ADDON_DAO.addAddon(addon)
                ? "Add-on added successfully."
                : "Failed to add add-on.");
    }


    private static void displayOrders() {
        printHeader("ORDERS");
        List<Order> list = ORDER_SERVICE.getAllOrders();
        if (list.isEmpty()) {
            System.out.println("No orders found.");
            return;
        }
        System.out.println("ID" + "\t" + "TABLE" + "\t" + "PEOPLE" + "\t" + "SHARING" + "\t" + "STATUS" + "\t" + "TOTAL" + "\t" + "TIME");
        line(95);
        for (Order o : list) {
            System.out.println(o.getOrderId() + "\t" + o.getTableId() + "\t" + o.getCustomerCount()
                    + "\t" + (o.isSharingAllowed() ? "YES" : "NO") + "\t" + safe(o.getOrderStatus())
                    + "\t₹" + o.getTotalAmount() + "\t" + String.valueOf(o.getOrderTime()));
        }
    }

    private static void displayPayments() {
        printHeader("PAYMENTS");
        List<Payment> list = PAYMENT_SERVICE.getAllPayments();
        if (list.isEmpty()) {
            System.out.println("No payments found.");
            return;
        }
        System.out.println("ID" + "\t" + "ORDER" + "\t" + "METHOD" + "\t" + "STATUS" + "\t" + "AMOUNT" + "\t" + "TIME");
        line(85);
        for (Payment p : list) {
            System.out.println(p.getPaymentId() + "\t" + p.getOrderId() + "\t" + safe(p.getPaymentMethod())
                    + "\t" + safe(p.getPaymentStatus()) + "\t₹" + p.getAmount() + "\t" + String.valueOf(p.getPaymentTime()));
        }
    }

    private static void displayFeedback() {
        printHeader("FEEDBACK");
        List<Feedback> list = FEEDBACK_DAO.getAllFeedback();
        if (list.isEmpty()) {
            System.out.println("No feedback found.");
            return;
        }
        System.out.println("ID" + "\t" + "ORDER" + "\t" + "RATING" + "\t" + "COMMENTS" + "\t" + "DATE");
        line(100);
        for (Feedback f : list) {
            System.out.println(f.getFeedbackId() + "\t" + f.getOrderId() + "\t" + f.getRating()
                    + "\t" + safe(f.getComments()) + "\t" + String.valueOf(f.getFeedbackDate()));
        }
    }


    private static void tableManagement() {
        while (true) {
            printHeader("TABLE MANAGEMENT");
            System.out.println("1. View Tables");
            System.out.println("2. Add Table");
            System.out.println("3. Update Table");
            System.out.println("4. Delete Table");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displayTables();
                case 2 -> addTable();
                case 3 -> updateTable();
                case 4 -> deleteTable();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displayTables() {
        printHeader("TABLES");
        List<Table> list = TABLE_DAO.getAllTables();
        System.out.println("ID" + "\t" + "NAME" + "\t" + "CAPACITY" + "\t" + "STATUS" + "\t" + "LOCATION");
        line(75);
        for (Table t : list) {
            System.out.println(t.getTableId() + "\t" + safe(t.getTableName()) + "\t" + t.getCapacity()
                    + "\t" + safe(t.getStatus()) + "\t" + safe(t.getLocation()));
        }
    }

    private static void addTable() {
        Table t = new Table();
        t.setTableName(readRequiredString("Table name: "));
        t.setCapacity(readIntRange("Capacity: ", 1, 100));
        t.setStatus(readRequiredString("Status: "));
        t.setLocation(readRequiredString("Location: "));
        System.out.println(TABLE_DAO.addTable(t) ? "Table added." : "Failed to add table.");
    }

    private static void updateTable() {
        int id = readInt("Table ID: ");
        Table t = TABLE_DAO.getTableById(id);
        if (t == null) {
            System.out.println("Table not found.");
            return;
        }
        t.setTableName(readRequiredString("Table name: "));
        t.setCapacity(readIntRange("Capacity: ", 1, 100));
        t.setStatus(readRequiredString("Status: "));
        t.setLocation(readRequiredString("Location: "));
        System.out.println(TABLE_DAO.updateTable(t) ? "Table updated." : "Failed to update table.");
    }

    private static void deleteTable() {
        int id = readInt("Table ID: ");
        if (!readYesNo("Delete this table? (Y/N): ")) return;
        System.out.println(TABLE_DAO.deleteTable(id) ? "Table deleted." : "Failed to delete table.");
    }

    private static void seatManagement() {
        while (true) {
            printHeader("SEAT MANAGEMENT");
            System.out.println("1. View Seats");
            System.out.println("2. Add Seat");
            System.out.println("3. Update Seat");
            System.out.println("4. Delete Seat");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displaySeats();
                case 2 -> addSeat();
                case 3 -> updateSeat();
                case 4 -> deleteSeat();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displaySeats() {
        printHeader("SEATS");
        List<Seat> list = SEAT_DAO.getAllSeats();
        System.out.println("ID" + "\t" + "TABLE" + "\t" + "SEAT NO" + "\t" + "STATUS");
        line(50);
        for (Seat s : list) {
            System.out.println(s.getSeatId() + "\t" + s.getTableId() + "\t" + s.getSeatNumber() + "\t" + safe(s.getStatus()));
        }
    }

    private static void addSeat() {
        Seat s = new Seat();
        s.setTableId(readInt("Table ID: "));
        s.setSeatNumber(readInt("Seat number: "));
        s.setStatus(readRequiredString("Status: "));
        System.out.println(SEAT_DAO.addSeat(s) ? "Seat added." : "Failed to add seat.");
    }

    private static void updateSeat() {
        int id = readInt("Seat ID: ");
        Seat s = SEAT_DAO.getSeatById(id);
        if (s == null) {
            System.out.println("Seat not found.");
            return;
        }
        s.setTableId(readInt("Table ID: "));
        s.setSeatNumber(readInt("Seat number: "));
        s.setStatus(readRequiredString("Status: "));
        System.out.println(SEAT_DAO.updateSeat(s) ? "Seat updated." : "Failed to update seat.");
    }

    private static void deleteSeat() {
        int id = readInt("Seat ID: ");
        if (!readYesNo("Delete this seat? (Y/N): ")) return;
        System.out.println(SEAT_DAO.deleteSeat(id) ? "Seat deleted." : "Failed to delete seat.");
    }


    private static void employeeManagement() {
        while (true) {
            printHeader("EMPLOYEE MANAGEMENT");
            System.out.println("1. View Employees");
            System.out.println("2. Add Employee");
            System.out.println("3. Employee Salary Summary");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displayEmployees();
                case 2 -> addEmployee();
                case 3 -> System.out.println("Monthly salary expense: ₹" + EMPLOYEE_SERVICE.calculateMonthlySalaryExpense());
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displayEmployees() {
        printHeader("EMPLOYEES");
        List<Employee> list = EMPLOYEE_SERVICE.getAllEmployees();
        System.out.println("ID" + "\t" + "NAME" + "\t" + "ROLE" + "\t" + "PHONE" + "\t" + "SALARY" + "\t" + "BONUS" + "\t" + "DEDUCTION");
        line(110);
        for (Employee e : list) {
            System.out.println(e.getEmployeeId() + "\t" + safe(e.getEmployeeName()) + "\t" + safe(e.getRole())
                    + "\t" + safe(e.getPhone()) + "\t₹" + e.getSalary() + "\t₹" + e.getBonus() + "\t₹" + e.getDeduction());
        }
    }

    private static void addEmployee() {
        Employee e = new Employee();
        e.setEmployeeName(readRequiredString("Employee name: "));
        e.setRole(readRequiredString("Role: "));
        e.setPhone(readRequiredString("Phone: "));
        e.setSalary(readDouble("Salary: "));
        e.setBonus(readDouble("Bonus: "));
        e.setDeduction(readDouble("Deduction: "));
        System.out.println(EMPLOYEE_SERVICE.addEmployee(e) ? "Employee added." : "Failed to add employee.");
    }


    private static void inventoryManagement() {
        while (true) {
            printHeader("INVENTORY MANAGEMENT");
            System.out.println("1. View Inventory");
            System.out.println("2. Add Inventory");
            System.out.println("3. Update Inventory");
            System.out.println("4. Delete Inventory");
            System.out.println("5. Low Stock");
            System.out.println("6. Inventory Value");
            System.out.println("7. Increase Stock");
            System.out.println("8. Reduce Stock");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displayInventory();
                case 2 -> addInventory();
                case 3 -> updateInventory();
                case 4 -> deleteInventory();
                case 5 -> displayLowStock();
                case 6 -> System.out.println("Inventory value: ₹" + INVENTORY_SERVICE.calculateInventoryValue());
                case 7 -> changeStock(true);
                case 8 -> changeStock(false);
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displayInventory() {
        printHeader("INVENTORY");
        List<Inventory> list = INVENTORY_SERVICE.getAllInventory();
        System.out.println("ID" + "\t" + "ITEM" + "\t" + "QUANTITY" + "\t" + "UNIT" + "\t" + "MIN STOCK" + "\t" + "PURCHASE PRICE");
        line(100);
        for (Inventory i : list) {
            System.out.println(i.getInventoryId() + "\t" + safe(i.getItemName()) + "\t" + i.getQuantity()
                    + "\t" + safe(i.getUnit()) + "\t" + i.getMinimumStock() + "\t₹" + i.getPurchasePrice());
        }
    }

    private static void addInventory() {
        Inventory i = new Inventory();
        i.setItemName(readRequiredString("Item name: "));
        i.setQuantity(readDouble("Quantity: "));
        i.setUnit(readRequiredString("Unit: "));
        i.setMinimumStock(readDouble("Minimum stock: "));
        i.setPurchasePrice(readDouble("Purchase price: "));
        System.out.println(INVENTORY_SERVICE.addInventory(i) ? "Inventory added." : "Failed to add inventory.");
    }

    private static void updateInventory() {
        int id = readInt("Inventory ID: ");
        Inventory i = INVENTORY_SERVICE.getInventoryById(id);
        if (i == null) {
            System.out.println("Inventory item not found.");
            return;
        }
        i.setItemName(readRequiredString("Item name: "));
        i.setQuantity(readDouble("Quantity: "));
        i.setUnit(readRequiredString("Unit: "));
        i.setMinimumStock(readDouble("Minimum stock: "));
        i.setPurchasePrice(readDouble("Purchase price: "));
        System.out.println(INVENTORY_SERVICE.updateInventory(i) ? "Inventory updated." : "Failed to update inventory.");
    }

    private static void deleteInventory() {
        int id = readInt("Inventory ID: ");
        if (!readYesNo("Delete this inventory item? (Y/N): ")) return;
        System.out.println(INVENTORY_SERVICE.deleteInventory(id) ? "Inventory deleted." : "Failed to delete inventory.");
    }

    private static void displayLowStock() {
        printHeader("LOW STOCK");
        boolean found = false;
        for (Inventory i : INVENTORY_SERVICE.getAllInventory()) {
            if (INVENTORY_SERVICE.isLowStock(i)) {
                System.out.println(i.getInventoryId() + "\t" + safe(i.getItemName()) + "\t" + i.getQuantity()
                        + "\t" + safe(i.getUnit()) + " minimum " + i.getMinimumStock());
                found = true;
            }
        }
        if (!found) System.out.println("No low-stock items.");
    }

    private static void changeStock(boolean increase) {
        int id = readInt("Inventory ID: ");
        double amount = readDouble(increase ? "Quantity to add: " : "Quantity to reduce: ");
        boolean success = increase
                ? INVENTORY_SERVICE.addStock(id, amount)
                : INVENTORY_SERVICE.reduceStock(id, amount);
        System.out.println(success ? "Stock updated." : "Stock update failed.");
    }


    private static void supplierManagement() {
        while (true) {
            printHeader("SUPPLIER MANAGEMENT");
            System.out.println("1. View Suppliers");
            System.out.println("2. Add Supplier");
            System.out.println("3. Update Supplier");
            System.out.println("4. Delete Supplier");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displaySuppliers();
                case 2 -> addSupplier();
                case 3 -> updateSupplier();
                case 4 -> deleteSupplier();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displaySuppliers() {
        printHeader("SUPPLIERS");
        List<Supplier> list = SUPPLIER_DAO.getAllSuppliers();
        System.out.println("ID" + "\t" + "NAME" + "\t" + "PHONE" + "\t" + "ADDRESS" + "\t" + "SUPPLIED ITEM");
        line(110);
        for (Supplier s : list) {
            System.out.println(s.getSupplierId() + "\t" + safe(s.getSupplierName()) + "\t" + safe(s.getPhone())
                    + "\t" + safe(s.getAddress()) + "\t" + safe(s.getSuppliedItem()));
        }
    }

    private static void addSupplier() {
        Supplier s = new Supplier();
        s.setSupplierName(readRequiredString("Supplier name: "));
        s.setPhone(readRequiredString("Phone: "));
        s.setAddress(readRequiredString("Address: "));
        s.setSuppliedItem(readRequiredString("Supplied item: "));
        System.out.println(SUPPLIER_DAO.addSupplier(s) ? "Supplier added." : "Failed to add supplier.");
    }

    private static void updateSupplier() {
        int id = readInt("Supplier ID: ");
        Supplier s = SUPPLIER_DAO.getSupplierById(id);
        if (s == null) {
            System.out.println("Supplier not found.");
            return;
        }
        s.setSupplierName(readRequiredString("Supplier name: "));
        s.setPhone(readRequiredString("Phone: "));
        s.setAddress(readRequiredString("Address: "));
        s.setSuppliedItem(readRequiredString("Supplied item: "));
        System.out.println(SUPPLIER_DAO.updateSupplier(s) ? "Supplier updated." : "Failed to update supplier.");
    }

    private static void deleteSupplier() {
        int id = readInt("Supplier ID: ");
        if (!readYesNo("Delete this supplier? (Y/N): ")) return;
        System.out.println(SUPPLIER_DAO.deleteSupplier(id) ? "Supplier deleted." : "Failed to delete supplier.");
    }

  
    private static void assetManagement() {
        while (true) {
            printHeader("ASSET MANAGEMENT");
            System.out.println("1. View Assets");
            System.out.println("2. Add Asset");
            System.out.println("3. Update Asset");
            System.out.println("4. Delete Asset");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displayAssets();
                case 2 -> addAsset();
                case 3 -> updateAsset();
                case 4 -> deleteAsset();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displayAssets() {
        printHeader("ASSETS");
        List<Asset> list = ASSET_DAO.getAllAssets();
        System.out.println("ID" + "\t" + "NAME" + "\t" + "CATEGORY" + "\t" + "QTY" + "\t" + "PRICE" + "\t" + "PURCHASE DATE");
        line(100);
        for (Asset a : list) {
            System.out.println(a.getAssetId() + "\t" + safe(a.getAssetName()) + "\t" + safe(a.getCategory())
                    + "\t" + a.getQuantity() + "\t₹" + a.getPrice() + "\t" + String.valueOf(a.getPurchaseDate()));
        }
    }

    private static void addAsset() {
        Asset a = new Asset();
        a.setAssetName(readRequiredString("Asset name: "));
        a.setCategory(readRequiredString("Category: "));
        a.setQuantity(readInt("Quantity: "));
        a.setPrice(readDouble("Price: "));
        a.setPurchaseDate(readDate("Purchase date (YYYY-MM-DD): "));
        System.out.println(ASSET_DAO.addAsset(a) ? "Asset added." : "Failed to add asset.");
    }

    private static void updateAsset() {
        int id = readInt("Asset ID: ");
        Asset a = ASSET_DAO.getAssetById(id);
        if (a == null) {
            System.out.println("Asset not found.");
            return;
        }
        a.setAssetName(readRequiredString("Asset name: "));
        a.setCategory(readRequiredString("Category: "));
        a.setQuantity(readInt("Quantity: "));
        a.setPrice(readDouble("Price: "));
        a.setPurchaseDate(readDate("Purchase date (YYYY-MM-DD): "));
        System.out.println(ASSET_DAO.updateAsset(a) ? "Asset updated." : "Failed to update asset.");
    }

    private static void deleteAsset() {
        int id = readInt("Asset ID: ");
        if (!readYesNo("Delete this asset? (Y/N): ")) return;
        System.out.println(ASSET_DAO.deleteAsset(id) ? "Asset deleted." : "Failed to delete asset.");
    }

    private static void expenseManagement() {
        while (true) {
            printHeader("EXPENSE MANAGEMENT");
            System.out.println("1. View Expenses");
            System.out.println("2. Add Expense");
            System.out.println("3. Update Expense");
            System.out.println("4. Delete Expense");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displayExpenses();
                case 2 -> addExpense();
                case 3 -> updateExpense();
                case 4 -> deleteExpense();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displayExpenses() {
        printHeader("EXPENSES");
        List<Expense> list = EXPENSE_DAO.getAllExpenses();
        System.out.println("ID" + "\t" + "NAME" + "\t" + "CATEGORY" + "\t" + "AMOUNT" + "\t" + "DATE");
        line(85);
        for (Expense e : list) {
            System.out.println(e.getExpenseId() + "\t" + safe(e.getExpenseName()) + "\t" + safe(e.getCategory())
                    + "\t₹" + e.getAmount() + "\t" + String.valueOf(e.getExpenseDate()));
        }
    }

    private static void addExpense() {
        Expense e = new Expense();
        e.setExpenseName(readRequiredString("Expense name: "));
        e.setCategory(readRequiredString("Category: "));
        e.setAmount(readDouble("Amount: "));
        e.setExpenseDate(readDate("Expense date (YYYY-MM-DD): "));
        System.out.println(EXPENSE_DAO.addExpense(e) ? "Expense added." : "Failed to add expense.");
    }

    private static void updateExpense() {
        int id = readInt("Expense ID: ");
        Expense e = EXPENSE_DAO.getExpenseById(id);
        if (e == null) {
            System.out.println("Expense not found.");
            return;
        }
        e.setExpenseName(readRequiredString("Expense name: "));
        e.setCategory(readRequiredString("Category: "));
        e.setAmount(readDouble("Amount: "));
        e.setExpenseDate(readDate("Expense date (YYYY-MM-DD): "));
        System.out.println(EXPENSE_DAO.updateExpense(e) ? "Expense updated." : "Failed to update expense.");
    }

    private static void deleteExpense() {
        int id = readInt("Expense ID: ");
        if (!readYesNo("Delete this expense? (Y/N): ")) return;
        System.out.println(EXPENSE_DAO.deleteExpense(id) ? "Expense deleted." : "Failed to delete expense.");
    }

 
    private static void utilityBillManagement() {
        while (true) {
            printHeader("UTILITY BILLS");
            System.out.println("1. View Bills");
            System.out.println("2. Add Bill");
            System.out.println("3. Update Bill");
            System.out.println("4. Delete Bill");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displayBills();
                case 2 -> addBill();
                case 3 -> updateBill();
                case 4 -> deleteBill();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displayBills() {
        printHeader("UTILITY BILLS");
        List<UtilityBill> list = BILL_DAO.getAllUtilityBills();
        System.out.println("ID" + "\t" + "TYPE" + "\t" + "AMOUNT" + "\t" + "MONTH" + "\t" + "YEAR" + "\t" + "STATUS");
        line(80);
        for (UtilityBill b : list) {
            System.out.println(b.getBillId() + "\t" + safe(b.getBillType()) + "\t₹" + b.getAmount()
                    + "\t" + safe(b.getBillMonth()) + "\t" + b.getBillYear() + "\t" + safe(b.getPaymentStatus()));
        }
    }

    private static void addBill() {
        UtilityBill b = new UtilityBill();
        b.setBillType(readRequiredString("Bill type: "));
        b.setAmount(readDouble("Amount: "));
        b.setBillMonth(readRequiredString("Bill month: "));
        b.setBillYear(readInt("Bill year: "));
        b.setPaymentStatus(readRequiredString("Payment status: "));
        System.out.println(BILL_DAO.addUtilityBill(b) ? "Bill added." : "Failed to add bill.");
    }

    private static void updateBill() {
        int id = readInt("Bill ID: ");
        UtilityBill b = BILL_DAO.getUtilityBillById(id);
        if (b == null) {
            System.out.println("Bill not found.");
            return;
        }
        b.setBillType(readRequiredString("Bill type: "));
        b.setAmount(readDouble("Amount: "));
        b.setBillMonth(readRequiredString("Bill month: "));
        b.setBillYear(readInt("Bill year: "));
        b.setPaymentStatus(readRequiredString("Payment status: "));
        System.out.println(BILL_DAO.updateUtilityBill(b) ? "Bill updated." : "Failed to update bill.");
    }

    private static void deleteBill() {
        int id = readInt("Bill ID: ");
        if (!readYesNo("Delete this bill? (Y/N): ")) return;
        System.out.println(BILL_DAO.deleteUtilityBill(id) ? "Bill deleted." : "Failed to delete bill.");
    }


    private static void maintenanceManagement() {
        while (true) {
            printHeader("MAINTENANCE");
            System.out.println("1. View Maintenance");
            System.out.println("2. Add Maintenance");
            System.out.println("3. Update Maintenance");
            System.out.println("4. Delete Maintenance");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displayMaintenance();
                case 2 -> addMaintenance();
                case 3 -> updateMaintenance();
                case 4 -> deleteMaintenance();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displayMaintenance() {
        printHeader("MAINTENANCE RECORDS");
        List<Maintenance> list = MAINTENANCE_DAO.getAllMaintenance();
        System.out.println("ID" + "\t" + "ITEM" + "\t" + "PROBLEM" + "\t" + "COST" + "\t" + "DATE" + "\t" + "TECHNICIAN");
        line(110);
        for (Maintenance m : list) {
            System.out.println(m.getMaintenanceId() + "\t" + safe(m.getItemName()) + "\t" + safe(m.getProblem())
                    + "\t₹" + m.getRepairCost() + "\t" + String.valueOf(m.getRepairDate()) + "\t" + safe(m.getTechnician()));
        }
    }

    private static void addMaintenance() {
        Maintenance m = new Maintenance();
        m.setItemName(readRequiredString("Item name: "));
        m.setProblem(readRequiredString("Problem: "));
        m.setRepairCost(readDouble("Repair cost: "));
        m.setRepairDate(readDate("Repair date (YYYY-MM-DD): "));
        m.setTechnician(readRequiredString("Technician: "));
        System.out.println(MAINTENANCE_DAO.addMaintenance(m) ? "Maintenance added." : "Failed to add maintenance.");
    }

    private static void updateMaintenance() {
        int id = readInt("Maintenance ID: ");
        Maintenance m = MAINTENANCE_DAO.getMaintenanceById(id);
        if (m == null) {
            System.out.println("Maintenance record not found.");
            return;
        }
        m.setItemName(readRequiredString("Item name: "));
        m.setProblem(readRequiredString("Problem: "));
        m.setRepairCost(readDouble("Repair cost: "));
        m.setRepairDate(readDate("Repair date (YYYY-MM-DD): "));
        m.setTechnician(readRequiredString("Technician: "));
        System.out.println(MAINTENANCE_DAO.updateMaintenance(m) ? "Maintenance updated." : "Failed to update maintenance.");
    }

    private static void deleteMaintenance() {
        int id = readInt("Maintenance ID: ");
        if (!readYesNo("Delete this maintenance record? (Y/N): ")) return;
        System.out.println(MAINTENANCE_DAO.deleteMaintenance(id) ? "Maintenance deleted." : "Failed to delete maintenance.");
    }


    private static void damageManagement() {
        while (true) {
            printHeader("DAMAGE MANAGEMENT");
            System.out.println("1. View Damage Records");
            System.out.println("2. Add Damage");
            System.out.println("3. Update Damage");
            System.out.println("4. Delete Damage");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displayDamages();
                case 2 -> addDamage();
                case 3 -> updateDamage();
                case 4 -> deleteDamage();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displayDamages() {
        printHeader("DAMAGE RECORDS");
        List<Damage> list = DAMAGE_DAO.getAllDamages();
        System.out.println("ID" + "\t" + "ITEM" + "\t" + "QTY" + "\t" + "DAMAGE COST" + "\t" + "STATUS");
        line(80);
        for (Damage d : list) {
            System.out.println(d.getDamageId() + "\t" + safe(d.getItemName()) + "\t" + d.getQuantity()
                    + "\t₹" + d.getDamageCost() + "\t" + safe(d.getStatus()));
        }
    }

    private static void addDamage() {
        Damage d = new Damage();
        d.setItemName(readRequiredString("Item name: "));
        d.setQuantity(readInt("Quantity: "));
        d.setDamageCost(readDouble("Damage cost: "));
        d.setStatus(readRequiredString("Status: "));
        System.out.println(DAMAGE_DAO.addDamage(d) ? "Damage record added." : "Failed to add damage record.");
    }

    private static void updateDamage() {
        int id = readInt("Damage ID: ");
        Damage d = DAMAGE_DAO.getDamageById(id);
        if (d == null) {
            System.out.println("Damage record not found.");
            return;
        }
        d.setItemName(readRequiredString("Item name: "));
        d.setQuantity(readInt("Quantity: "));
        d.setDamageCost(readDouble("Damage cost: "));
        d.setStatus(readRequiredString("Status: "));
        System.out.println(DAMAGE_DAO.updateDamage(d) ? "Damage record updated." : "Failed to update damage record.");
    }

    private static void deleteDamage() {
        int id = readInt("Damage ID: ");
        if (!readYesNo("Delete this damage record? (Y/N): ")) return;
        System.out.println(DAMAGE_DAO.deleteDamage(id) ? "Damage record deleted." : "Failed to delete damage record.");
    }

    private static void attendanceManagement() {
        while (true) {
            printHeader("ATTENDANCE");
            System.out.println("1. View Attendance");
            System.out.println("2. Add Attendance");
            System.out.println("3. Update Attendance");
            System.out.println("4. Delete Attendance");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displayAttendance();
                case 2 -> addAttendance();
                case 3 -> updateAttendance();
                case 4 -> deleteAttendance();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displayAttendance() {
        printHeader("ATTENDANCE RECORDS");
        List<Attendance> list = ATTENDANCE_DAO.getAllAttendance();
        System.out.println("ID" + "\t" + "EMPLOYEE" + "\t" + "DATE" + "\t" + "STATUS");
        line(60);
        for (Attendance a : list) {
            System.out.println(a.getAttendanceId() + "\t" + a.getEmployeeId() + "\t" + String.valueOf(a.getAttendanceDate()) + "\t" + safe(a.getStatus()));
        }
    }

    private static void addAttendance() {
        Attendance a = new Attendance();
        a.setEmployeeId(readInt("Employee ID: "));
        a.setAttendanceDate(readDate("Attendance date (YYYY-MM-DD): "));
        a.setStatus(readRequiredString("Status (PRESENT/ABSENT/etc.): "));
        System.out.println(ATTENDANCE_DAO.addAttendance(a) ? "Attendance added." : "Failed to add attendance.");
    }

    private static void updateAttendance() {
        int id = readInt("Attendance ID: ");
        Attendance a = ATTENDANCE_DAO.getAttendanceById(id);
        if (a == null) {
            System.out.println("Attendance record not found.");
            return;
        }
        a.setEmployeeId(readInt("Employee ID: "));
        a.setAttendanceDate(readDate("Attendance date (YYYY-MM-DD): "));
        a.setStatus(readRequiredString("Status: "));
        System.out.println(ATTENDANCE_DAO.updateAttendance(a) ? "Attendance updated." : "Failed to update attendance.");
    }

    private static void deleteAttendance() {
        int id = readInt("Attendance ID: ");
        if (!readYesNo("Delete this attendance record? (Y/N): ")) return;
        System.out.println(ATTENDANCE_DAO.deleteAttendance(id) ? "Attendance deleted." : "Failed to delete attendance.");
    }


    private static void leaveManagement() {
        while (true) {
            printHeader("LEAVE MANAGEMENT");
            System.out.println("1. View Leaves");
            System.out.println("2. Add Leave");
            System.out.println("3. Update Leave");
            System.out.println("4. Delete Leave");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> displayLeaves();
                case 2 -> addLeave();
                case 3 -> updateLeave();
                case 4 -> deleteLeave();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void displayLeaves() {
        printHeader("LEAVE RECORDS");
        List<Leave> list = LEAVE_DAO.getAllLeaves();
        System.out.println("ID" + "\t" + "EMPLOYEE" + "\t" + "FROM" + "\t" + "TO" + "\t" + "REASON" + "\t" + "STATUS");
        line(100);
        for (Leave l : list) {
            System.out.println(l.getLeaveId() + "\t" + l.getEmployeeId() + "\t" + String.valueOf(l.getLeaveFrom())
                    + "\t" + String.valueOf(l.getLeaveTo()) + "\t" + safe(l.getReason()) + "\t" + safe(l.getStatus()));
        }
    }

    private static void addLeave() {
        Leave l = new Leave();
        l.setEmployeeId(readInt("Employee ID: "));
        l.setLeaveFrom(readDate("Leave from (YYYY-MM-DD): "));
        l.setLeaveTo(readDate("Leave to (YYYY-MM-DD): "));
        l.setReason(readRequiredString("Reason: "));
        l.setStatus(readRequiredString("Status: "));
        System.out.println(LEAVE_DAO.addLeave(l) ? "Leave added." : "Failed to add leave.");
    }

    private static void updateLeave() {
        int id = readInt("Leave ID: ");
        Leave l = LEAVE_DAO.getLeaveById(id);
        if (l == null) {
            System.out.println("Leave record not found.");
            return;
        }
        l.setEmployeeId(readInt("Employee ID: "));
        l.setLeaveFrom(readDate("Leave from (YYYY-MM-DD): "));
        l.setLeaveTo(readDate("Leave to (YYYY-MM-DD): "));
        l.setReason(readRequiredString("Reason: "));
        l.setStatus(readRequiredString("Status: "));
        System.out.println(LEAVE_DAO.updateLeave(l) ? "Leave updated." : "Failed to update leave.");
    }

    private static void deleteLeave() {
        int id = readInt("Leave ID: ");
        if (!readYesNo("Delete this leave record? (Y/N): ")) return;
        System.out.println(LEAVE_DAO.deleteLeave(id) ? "Leave deleted." : "Failed to delete leave.");
    }

 
    private static void reportMenu() {
        while (true) {
            printHeader("REPORTS");
            System.out.println("1. Full Dashboard Summary");
            System.out.println("2. Revenue");
            System.out.println("3. Expenses");
            System.out.println("4. Net Profit");
            System.out.println("5. Orders");
            System.out.println("6. Employees");
            System.out.println("7. Inventory Value");
            System.out.println("8. Average Order Value");
            System.out.println("9. Today's Revenue");
            System.out.println("10. Successful Payments");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> REPORT_SERVICE.printDashboardSummary();
                case 2 -> System.out.println("Total revenue: ₹" + REPORT_SERVICE.getTotalRevenue());
                case 3 -> System.out.println("Total expenses: ₹" + REPORT_SERVICE.getTotalExpenses());
                case 4 -> System.out.println("Net profit: ₹" + REPORT_SERVICE.getNetProfit());
                case 5 -> System.out.println("Total orders: " + REPORT_SERVICE.getTotalOrders());
                case 6 -> System.out.println("Total employees: " + REPORT_SERVICE.getTotalEmployees());
                case 7 -> System.out.println("Inventory value: ₹" + REPORT_SERVICE.getInventoryValue());
                case 8 -> System.out.println("Average order value: ₹" + REPORT_SERVICE.getAverageOrderValue());
                case 9 -> System.out.println("Today's revenue: ₹" + PAYMENT_SERVICE.getTodayRevenue());
                case 10 -> System.out.println("Successful payments: " + PAYMENT_SERVICE.getSuccessfulPaymentCount());
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }


    private static void adminAccountManagement() {
        while (true) {
            printHeader("ADMIN ACCOUNT");
            System.out.println("1. Add Admin");
            System.out.println("2. View Admin By ID");
            System.out.println("3. Update Admin");
            System.out.println("4. Delete Admin");
            System.out.println("0. Back");
            int choice = readInt("Select option: ");
            switch (choice) {
                case 1 -> addAdmin();
                case 2 -> viewAdmin();
                case 3 -> updateAdmin();
                case 4 -> deleteAdmin();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void addAdmin() {
        Admin admin = new Admin();
        admin.setUsername(readRequiredString("Username: "));
        admin.setPassword(readRequiredString("Password: "));
        System.out.println(ADMIN_DAO.addAdmin(admin) ? "Admin added." : "Failed to add admin.");
    }

    private static void viewAdmin() {
        int id = readInt("Admin ID: ");
        Admin admin = ADMIN_DAO.getAdminById(id);
        if (admin == null) {
            System.out.println("Admin not found.");
            return;
        }
        System.out.println("Admin ID : " + admin.getAdminId());
        System.out.println("Username : " + admin.getUsername());
        System.out.println("Password : [hidden]");
    }

    private static void updateAdmin() {
        int id = readInt("Admin ID: ");
        Admin admin = ADMIN_DAO.getAdminById(id);
        if (admin == null) {
            System.out.println("Admin not found.");
            return;
        }
        admin.setUsername(readRequiredString("New username: "));
        admin.setPassword(readRequiredString("New password: "));
        System.out.println(ADMIN_DAO.updateAdmin(admin) ? "Admin updated." : "Failed to update admin.");
    }

    private static void deleteAdmin() {
        int id = readInt("Admin ID: ");
        if (!readYesNo("Delete this admin? (Y/N): ")) return;
        System.out.println(ADMIN_DAO.deleteAdmin(id) ? "Admin deleted." : "Failed to delete admin.");
    }


    private static void systemInformation() {
        printHeader("SYSTEM INFORMATION");
        System.out.println("Application : Smart Tea Stall Management System");
        System.out.println("CLI         : Java Console");
        System.out.println("Backend     : Java");
        System.out.println("Database    : MySQL");
        System.out.println("Connectivity: JDBC");
        System.out.println("Architecture: Model / DAO / Service / CLI / JavaFX");
        System.out.println("Data source : MySQL database (not hardcoded menu data)");
        System.out.println("Interface   : This CLI and the JavaFX interface share the same backend.");
    }


    private static String readLine(String prompt) {
        System.out.print(prompt);
        return SC.nextLine().trim();
    }

    private static String readRequiredString(String prompt) {
        while (true) {
            String value = readLine(prompt);
            if (!value.isEmpty()) return value;
            System.out.println("This field cannot be empty.");
        }
    }

    private static int readInt(String prompt) {
        while (true) {
            try {
                return Integer.parseInt(readLine(prompt));
            } catch (NumberFormatException e) {
                System.out.println("Enter a valid integer.");
            }
        }
    }

    private static int readIntRange(String prompt, int min, int max) {
        while (true) {
            int value = readInt(prompt);
            if (value >= min && value <= max) return value;
            System.out.println("Enter a value from " + min + " to " + max + ".");
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            try {
                double value = Double.parseDouble(readLine(prompt));
                if (value >= 0) return value;
                System.out.println("Value cannot be negative.");
            } catch (NumberFormatException e) {
                System.out.println("Enter a valid number.");
            }
        }
    }

    private static Date readDate(String prompt) {
        while (true) {
            try {
                return Date.valueOf(readLine(prompt));
            } catch (IllegalArgumentException e) {
                System.out.println("Use YYYY-MM-DD format.");
            }
        }
    }

    private static boolean readYesNo(String prompt) {
        while (true) {
            String value = readLine(prompt).toLowerCase();
            if (value.equals("y") || value.equals("yes")) return true;
            if (value.equals("n") || value.equals("no")) return false;
            System.out.println("Enter Y or N.");
        }
    }

    private static void printHeader(String title) {
        System.out.println();
        line(78);
        System.out.println(center(title, 78));
        line(78);
    }

    private static void line(int length) {
        System.out.println("-".repeat(Math.max(1, length)));
    }

    private static String center(String text, int width) {
        if (text.length() >= width) return text;
        int left = (width - text.length()) / 2;
        return " ".repeat(left) + text;
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    private static boolean isAvailable(String status) {
        if (status == null) return false;
        return status.equalsIgnoreCase("AVAILABLE")
                || status.equalsIgnoreCase("FREE")
                || status.equalsIgnoreCase("OPEN");
    }

    private static double cartTotal() {
        double total = 0;
        for (CartLine line : CART) {
            total += line.item.getPrice() * line.quantity;
        }
        return total;
    }

    private static class CartLine {
        private final MenuItem item;
        private int quantity;

        private CartLine(MenuItem item, int quantity) {
            this.item = item;
            this.quantity = quantity;
        }
    }
}