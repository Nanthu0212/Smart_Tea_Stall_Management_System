package com.smartteastall.service;

import java.util.List;

import com.smartteastall.dao.EmployeeDAO;
import com.smartteastall.model.Employee;

public class EmployeeService {

    private EmployeeDAO employeeDAO = new EmployeeDAO();


    public boolean addEmployee(Employee employee) {

        return employeeDAO.addEmployee(employee);

    }


    public List<Employee> getAllEmployees() {

        return employeeDAO.getAllEmployees();

    }


    public double calculateNetSalary(Employee employee) {

        return employee.getSalary()
                + employee.getBonus()
                - employee.getDeduction();

    }

    public double calculateMonthlySalaryExpense() {

        double total = 0;

        List<Employee> employees = employeeDAO.getAllEmployees();

        for (Employee employee : employees) {

            total += calculateNetSalary(employee);

        }

        return total;

    }


    public Employee getEmployeeById(int employeeId) {

        for (Employee employee : employeeDAO.getAllEmployees()) {

            if (employee.getEmployeeId() == employeeId) {

                return employee;

            }

        }

        return null;

    }


    public int getEmployeeCount() {

        return employeeDAO.getAllEmployees().size();

    }

}