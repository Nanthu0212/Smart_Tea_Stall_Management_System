package com.smartteastall.service;

import java.util.List;

import com.smartteastall.dao.OrderDAO;
import com.smartteastall.dao.OrderItemDAO;
import com.smartteastall.model.Order;
import com.smartteastall.model.OrderItem;

public class OrderService {

    private OrderDAO orderDAO = new OrderDAO();
    private OrderItemDAO orderItemDAO = new OrderItemDAO();

    public boolean createOrder(Order order) {
        return orderDAO.addOrder(order);
    }


    public boolean addOrderItem(OrderItem item) {
        return orderItemDAO.addOrderItem(item);
    }


    public List<Order> getAllOrders() {
        return orderDAO.getAllOrders();
    }

    public List<OrderItem> getAllOrderItems() {
        return orderItemDAO.getAllOrderItems();
    }

    public double calculateTotal(List<OrderItem> items) {

        double total = 0;

        for (OrderItem item : items) {
            total += item.getSubtotal();
        }

        return total;
    }

}