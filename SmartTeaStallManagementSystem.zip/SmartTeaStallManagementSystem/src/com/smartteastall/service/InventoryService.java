package com.smartteastall.service;

import java.util.List;

import com.smartteastall.dao.InventoryDAO;
import com.smartteastall.model.Inventory;

public class InventoryService {

    private InventoryDAO inventoryDAO = new InventoryDAO();

    public boolean addInventory(Inventory inventory) {

        return inventoryDAO.addInventory(inventory);

    }

    public List<Inventory> getAllInventory() {

        return inventoryDAO.getAllInventory();

    }


    public Inventory getInventoryById(int inventoryId) {

        return inventoryDAO.getInventoryById(inventoryId);

    }

    public boolean updateInventory(Inventory inventory) {

        return inventoryDAO.updateInventory(inventory);

    }


    public boolean deleteInventory(int inventoryId) {

        return inventoryDAO.deleteInventory(inventoryId);

    }


    public boolean isLowStock(Inventory inventory) {

        return inventory.getQuantity() <= inventory.getMinimumStock();

    }

    public double calculateInventoryValue() {

        double totalValue = 0;

        List<Inventory> inventoryList = inventoryDAO.getAllInventory();

        for (Inventory item : inventoryList) {

            totalValue += item.getQuantity() * item.getPurchasePrice();

        }

        return totalValue;

    }


    public boolean reduceStock(int inventoryId, double usedQuantity) {

        Inventory inventory = inventoryDAO.getInventoryById(inventoryId);

        if (inventory == null) {
            return false;
        }

        if (inventory.getQuantity() < usedQuantity) {
            return false;
        }

        inventory.setQuantity(inventory.getQuantity() - usedQuantity);

        return inventoryDAO.updateInventory(inventory);

    }

    public boolean addStock(int inventoryId, double addedQuantity) {

        Inventory inventory = inventoryDAO.getInventoryById(inventoryId);

        if (inventory == null) {
            return false;
        }

        inventory.setQuantity(inventory.getQuantity() + addedQuantity);

        return inventoryDAO.updateInventory(inventory);

    }

}