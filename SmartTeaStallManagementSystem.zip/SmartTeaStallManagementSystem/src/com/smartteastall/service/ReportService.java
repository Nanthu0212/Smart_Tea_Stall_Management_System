package com.smartteastall.service;

import java.util.List;

import com.smartteastall.dao.EmployeeDAO;
import com.smartteastall.dao.ExpenseDAO;
import com.smartteastall.dao.InventoryDAO;
import com.smartteastall.dao.OrderDAO;
import com.smartteastall.dao.PaymentDAO;
import com.smartteastall.model.Employee;
import com.smartteastall.model.Expense;
import com.smartteastall.model.Inventory;
import com.smartteastall.model.Order;
import com.smartteastall.model.Payment;

public class ReportService {

    private PaymentDAO paymentDAO = new PaymentDAO();
    private OrderDAO orderDAO = new OrderDAO();
    private EmployeeDAO employeeDAO = new EmployeeDAO();
    private InventoryDAO inventoryDAO = new InventoryDAO();
    private ExpenseDAO expenseDAO = new ExpenseDAO();


    public double getTotalRevenue() {

        double total = 0;

        List<Payment> payments = paymentDAO.getAllPayments();

        for (Payment payment : payments) {

            if (payment.getPaymentStatus().equalsIgnoreCase("PAID")) {

                total += payment.getAmount();

            }

        }

        return total;
    }

    public double getTotalExpenses() {

        double total = 0;

        List<Expense> expenses = expenseDAO.getAllExpenses();

        for (Expense expense : expenses) {

            total += expense.getAmount();

        }

        return total;
    }

    public double getNetProfit() {

        return getTotalRevenue() - getTotalExpenses();

    }


    public int getTotalOrders() {

        List<Order> orders = orderDAO.getAllOrders();

        return orders.size();

    }


    public int getTotalEmployees() {

        List<Employee> employees = employeeDAO.getAllEmployees();

        return employees.size();

    }


    public double getInventoryValue() {

        double total = 0;

        List<Inventory> inventory = inventoryDAO.getAllInventory();

        for (Inventory item : inventory) {

            total += item.getQuantity() * item.getPurchasePrice();

        }

        return total;

    }


    public double getAverageOrderValue() {

        int totalOrders = getTotalOrders();

        if (totalOrders == 0) {

            return 0;

        }

        return getTotalRevenue() / totalOrders;

    }


    public void printDashboardSummary() {

        System.out.println("===================================");

        System.out.println(" SMART TEA STALL DASHBOARD ");

        System.out.println("===================================");

        System.out.println("Total Revenue : ₹ " + getTotalRevenue());

        System.out.println("Total Expenses : ₹ " + getTotalExpenses());

        System.out.println("Net Profit : ₹ " + getNetProfit());

        System.out.println("Total Orders : " + getTotalOrders());

        System.out.println("Employees : " + getTotalEmployees());

        System.out.println("Inventory Value : ₹ " + getInventoryValue());

        System.out.println("Average Order Value : ₹ " + getAverageOrderValue());

        System.out.println("===================================");

    }

}