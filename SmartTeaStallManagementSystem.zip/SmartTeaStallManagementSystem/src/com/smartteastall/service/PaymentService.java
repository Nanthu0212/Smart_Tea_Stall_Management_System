package com.smartteastall.service;

import java.util.List;

import com.smartteastall.dao.PaymentDAO;
import com.smartteastall.model.Payment;

public class PaymentService {

    private PaymentDAO paymentDAO = new PaymentDAO();

    public boolean makePayment(Payment payment) {

        return paymentDAO.addPayment(payment);

    }


    public List<Payment> getAllPayments() {

        return paymentDAO.getAllPayments();

    }

    public double getTotalRevenue() {

        double total = 0;

        List<Payment> payments = paymentDAO.getAllPayments();

        for (Payment payment : payments) {

            if (payment.getPaymentStatus().equalsIgnoreCase("PAID")) {

                total += payment.getAmount();

            }

        }

        return total;

    }

    public double getTodayRevenue() {

        double total = 0;

        List<Payment> payments = paymentDAO.getAllPayments();

        java.sql.Date today =
                new java.sql.Date(System.currentTimeMillis());

        for (Payment payment : payments) {

            if (payment.getPaymentTime() != null &&
                payment.getPaymentStatus().equalsIgnoreCase("PAID")) {

                java.sql.Date paymentDate =
                        new java.sql.Date(payment.getPaymentTime().getTime());

                if (paymentDate.equals(today)) {

                    total += payment.getAmount();

                }

            }

        }

        return total;

    }

    public int getSuccessfulPaymentCount() {

        int count = 0;

        List<Payment> payments = paymentDAO.getAllPayments();

        for (Payment payment : payments) {

            if (payment.getPaymentStatus().equalsIgnoreCase("PAID")) {

                count++;

            }

        }

        return count;

    }

}